<html>
    <head>
        <title>Register Consultant</title>
    </head>
    <body>
        Name: {{$name}}<br>
        Email: {{$email}}<br>
        Password: {{$password}}<br>
    </body>
</html>