<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
<link rel="stylesheet" href="{{ asset('css/font-awesome.min.css') }}">
<link href="{{ asset('css/material-dashboard.minf066.css?v=2.1.0') }}" rel="stylesheet" />
<link href="{{ asset('demo/demo.css') }}" rel="stylesheet" />
<link rel="stylesheet" href="http://cdn.bootcss.com/toastr.js/latest/css/toastr.min.css">
<link href="{{ asset('lobibox/dist/css/lobibox.css') }}" rel="stylesheet" type="text/css">
<link href="{{ asset('lobibox/dist/css/lobibox.min.css') }}" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link href="{{ asset('css/custom_style.css') }}" rel="stylesheet" />
