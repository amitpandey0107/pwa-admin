<?php $urlName = Request::segment(2); ?>
<div class="sidebar" data-color="rose" data-background-color="black" data-image="<?php echo e(asset('img/sidebar-1.jpg')); ?>">
    <div class="logo">
        <a href="javacript:void(0)" class="simple-text logo-mini">
            <img src="<?php echo e(asset('images/favicon-32x32.png')); ?>"/>
        </a>
        <a href="<?php echo e(route('dashboard')); ?>" class="simple-text logo-normal">
            Farmer
        </a>
    </div>
    <div class="sidebar-wrapper">
        <ul class="nav">
            <li class="nav-item <?php if($urlName == '/' || $urlName == 'dashboard'){ echo "active"; }       ?>">
                <a class="nav-link" href="<?php echo e(route('dashboard')); ?>">
                    <i class="material-icons">dashboard</i>
                    <p> Dashboard </p>
                </a>
            </li>          
            <li class="nav-item <?php if($urlName == 'consultant-add' || $urlName == 'consultants' || $urlName == 'consultant-edit' || $urlName == 'consultant-view'){ echo "active"; }       ?>">
                <a class="nav-link" href="<?php echo e(route('consultants')); ?>">
                    <i class="material-icons">people_alt</i>
                    <p> Manage Consultants </p>
                </a>
            </li>

            <li class="nav-item <?php if($urlName == 'add-service' || $urlName == 'services' || $urlName=='edit-service' || $urlName == 'service-view'){ echo "active"; }       ?>">
                <a class="nav-link" href="<?php echo e(route('services')); ?>">
                    <i class="material-icons">build</i>
                    <p> Manage Services </p>
                </a>
            </li> 

            <li class="nav-item <?php if($urlName == 'categories' || $urlName == 'category-add' || $urlName == 'category-edit' || $urlName == 'category-view'){ echo "active"; }       ?>">
                <a class="nav-link" href="<?php echo e(route('categories')); ?>">
                    <i class="material-icons">category</i>
                    <p> Manage Categories </p>
                </a>
            </li>


           <li class="nav-item <?php if($urlName == 'customers' || $urlName == 'customer-add' || $urlName == 'customer-edit' || $urlName == 'customer-view'){ echo "active"; }       ?>">
                <a class="nav-link" href="<?php echo e(route('customers')); ?>">
                    <i class="material-icons">people_alt</i>
                    <p> Manage Customers </p>
                </a>
            </li>

            <li class="nav-item <?php if($urlName == 'farms' || $urlName == 'farm-add' || $urlName == 'farm-edit' || $urlName == 'farm-view'){ echo "active"; }       ?>">
                <a class="nav-link" href="<?php echo e(route('farms')); ?>">
                    <i class="material-icons">local_florist</i>
                    <p> Manage Farm </p>
                </a>
            </li>

            <li class="nav-item <?php if($urlName == 'leads' || $urlName == 'lead-add' || $urlName == 'lead-edit' || $urlName == 'lead-view'){ echo "active"; }       ?>">
                <a class="nav-link" href="<?php echo e(route('leads')); ?>">
                    <i class="material-icons">dynamic_feed</i>
                    <p> Manage Leads </p>
                </a>
            </li>

            <li class="nav-item <?php echo ($urlName == 'cms-page-list' || $urlName == 'cms-page-view') ? "active" : ""; ?> ">
                <a class="nav-link" href="<?php echo e(route('cms-page-list')); ?>">
                    <i class="material-icons">menu_book</i>
                    <p> CMS Pages </p>
                </a>
            </li>

            <li class="nav-item <?php echo ($urlName == 'status' || $urlName == 'status-add' || $urlName == 'status-edit' || $urlName == 'status-view') ? "active" : ""; ?> ">
                <a class="nav-link" href="<?php echo e(route('status')); ?>">
                    <i class="material-icons">sync</i>
                    <p> Status Management </p>
                </a>
            </li>


           <!--  <li class="nav-item <?php //if($urlName == '/' || $urlName == 'dashboard'){ echo "active"; }       ?>">
                <a class="nav-link" href="">
                    <i class="material-icons">dashboard</i>
                    <p> Manage Reports </p>
                </a>
            </li>          
            <li class="nav-item <?php //if($urlName == '/' || $urlName == 'dashboard'){ echo "active"; }       ?>">
                <a class="nav-link" href="">
                    <i class="material-icons">dashboard</i>
                    <p> Manage Surveys </p>
                </a>
            </li>          
            <li class="nav-item <?php //if($urlName == '/' || $urlName == 'dashboard'){ echo "active"; }       ?>">
                <a class="nav-link" href="">
                    <i class="material-icons">dashboard</i>
                    <p> Manage Services </p>
                </a>
            </li>          
            <li class="nav-item <?php //if($urlName == '/' || $urlName == 'dashboard'){ echo "active"; }       ?>">
                <a class="nav-link" href="">
                    <i class="material-icons">dashboard</i>
                    <p> CMS Management </p>
                </a>
            </li>          
            <li class="nav-item <?php //if($urlName == '/' || $urlName == 'dashboard'){ echo "active"; }       ?>">
                <a class="nav-link" href="">
                    <i class="material-icons">dashboard</i>
                    <p> Email/Notification </p>
                </a>
            </li>          
            <li class="nav-item <?php //if($urlName == '/' || $urlName == 'dashboard'){ echo "active"; }       ?>">
                <a class="nav-link" href="">
                    <i class="material-icons">dashboard</i>
                    <p> Execute Campaigns </p>
                </a>
            </li>          
            <li class="nav-item <?php //if($urlName == '/' || $urlName == 'dashboard'){ echo "active"; }       ?>">
                <a class="nav-link" href="">
                    <i class="material-icons">dashboard</i>
                    <p> Surveys </p>
                </a>
            </li>          -->
        </ul>
    </div>
</div>
