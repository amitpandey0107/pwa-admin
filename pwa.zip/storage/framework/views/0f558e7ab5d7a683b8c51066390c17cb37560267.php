<link rel="stylesheet" type="text/css" href="<?php echo asset('lobibox/font-awesome/css/font-awesome.min.css'); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo asset('lobibox/dist/css/lobibox.min.css'); ?>">
<script type="text/javascript" src="<?php echo asset('lobibox/js/lobibox.js'); ?>"></script>
<?php if(isset($errors)): ?>
    <?php if($errors->any()): ?>
        <script>
            $(function () {
                (function () {
                    Lobibox.notify('error', {
                        rounded: false,
                        delay: 4000,
                        delayIndicator: true,
                        msg: "<?php foreach($errors->all() as $error){ echo $error."<br>"; } ?>"
                    });
                })();
            });
        </script>
    <?php endif; ?>
<?php endif; ?>
<?php if(session()->has('success') or session()->has('warning') or session()->has('info') or session()->has('danger') or session()->has('error')  or session()->has('status')): ?>
    <?php $__currentLoopData = ['danger', 'warning', 'success', 'info','error','status']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(session()->has($msg)): ?>
            <script>
                var msgType = "<?php echo e($msg); ?>";
                if(msgType=='status')
                {
                    msgType = 'success';
                }
                $(function () {
                    (function () {
                        Lobibox.notify(msgType, {
                            rounded: false,
                            delay: 4000,
                            delayIndicator: true,
                            msg: "<?php echo e(session()->get($msg)); ?>"
                        });
                    })();
                });
            </script>
            <?php  session()->forget($msg); ?>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<style type="text/css">
    .lobibox-notify-msg{max-height:100px !important;}
</style>