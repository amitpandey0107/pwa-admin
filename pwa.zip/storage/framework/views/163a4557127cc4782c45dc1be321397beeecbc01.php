<?php $__env->startSection('admin::title', 'consultant'); ?>

<?php $__env->startSection('admin::pagetitle', 'Email consultant'); ?>

<?php $__env->startSection('admin::content'); ?>

<style>
    .statchk .form-check-label {margin-top: 14px;}
    .imgmt{margin-top: 20px;}
</style>

<div class="content">
    <div class="container-fluid">
                <div class="row">
                    <div class="col-sm-12">
                        <?php if(count($errors) > 0): ?>
                        <div class = "alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <?php endif; ?>
        
                        <?php if(!empty($successMsg)): ?>
                        <div class="alert alert-success"> <?php echo e($successMsg); ?></div>
                        <?php endif; ?>
                    </div>
                </div>

        <div class="row">
            <div class="col-sm-12">
                <?php if(session()->has('success')): ?>
                <?php $__env->startSection('admin::custom_js'); ?>
                <script>
                    Swal.fire({
                        position: 'center',
                        type: 'success',
                        title: " <?php echo e(session()->get('success')); ?> ",
                        showConfirmButton: false,
                        timer: 3000
                    })
                </script>
                <?php $__env->stopSection(); ?>

                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="content">
        <div class="container-fluid">
            <div class="row">                
                <div class="col-md-12">
                    <div class="card ">                       
                        <div class="card-header card-header-success card-header-icon">
                            <div class="card-icon">
                                <i class="material-icons">assignment</i>
                            </div>
                            <h4 class="card-title">Send Email Form
                                <a href="<?php echo e(route('consultants')); ?>">
                                    <button class="btn btn-success" style="float:right">Back</button>
                                </a>
                            </h4>
                        </div>
                        <div class="card-body">	
                            <form method="POST" class="form-horizontal" id="consultantForm" enctype="multipart/form-data" action="<?php echo e(route('consultant-email')); ?>">
                                <?php echo csrf_field(); ?>

                                <div class="row">
                                    <div class="col-sm-2 col-form-label">
                                        <label for="to" class="bmd-label-floating">To *</label>
                                    </div>	
                                    <div class="col-sm-10">
                                        <div class="form-group bmd-form-group">
                                            <input type="text" value="<?php echo e($user->email); ?>" class="form-control" disabled>
                                            <input type="hidden" name="email" id="email" value="<?php echo e($user->email); ?>">
                                            <input type="hidden" name="slug" id="slug" value="<?php echo e($user->slug); ?>">
                                            <input type="hidden" name="name" id="name" value="<?php echo e($user->name); ?>">
                                            <input type="hidden" name="id" id="id" value="<?php echo e($user->id); ?>">
                                        </div>
                                    </div>
                                </div>


                                <div class="row">
                                    <div class="col-sm-2 col-form-label">
                                        <label for="subject" class="bmd-label-floating">Subject *</label>
                                    </div>	
                                    <div class="col-sm-10">
                                        <div class="form-group bmd-form-group">
                                            <input type="text" name="subject" id="subject" class="form-control required" autocomplete="off"  value="<?php echo e(old('subject')); ?>">
                                            <?php if($errors->has('subject')): ?>
                                            <span class="error" role="subject">
                                                <strong><?php echo e($errors->first('subject')); ?></strong>
                                            </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-sm-2 col-form-label">
                                        <label for="message" class="bmd-label-floating">Message *</label>
                                    </div>	
                                    <div class="col-sm-10">
                                        <div class="form-group bmd-form-group">
                                            <textarea name="message" id="message" cols="30" rows="10" class="form-control required" autocomplete="off"  value="<?php echo e(old('message')); ?>"></textarea>
                                            <?php if($errors->has('message')): ?>
                                            <span class="error" role="message">
                                                <strong><?php echo e($errors->first('message')); ?></strong>
                                            </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                               
                                <div class="row">
                                    <div class="col-sm-2 col-form-label">
                                        <div class="card-footer ">
                                            <button type="submit" class="btn btn-fill btn-success">Send<div class="ripple-container"></div></button>
                                        </div>
                                    </div>				                   
                                </div>
                            </form>
                        </div>
                    </div>
                    <!-- /card -->

                </div>
            </div>
            <!-- /row -->
        </div>
        <!-- /container-fluid -->
    </div>
    <!-- /content -->
</div>
<!-- content -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('admin::custom_js'); ?>
<script type="text/javascript">
    $(document).ready(function () {
        $('#consultantForm').validate({
            rules:{
                subject:"required",                
                message:"required",
            }, 
            messages:{
              subject:"please enter email subject",                
              message:"please enter your message",
            }
        });

        $(".datepicker").datepicker({
            dateFormat: "yy-mm-dd",
            maxDate: new Date(),
            changeMonth: true,
            changeYear: true
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin::layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>