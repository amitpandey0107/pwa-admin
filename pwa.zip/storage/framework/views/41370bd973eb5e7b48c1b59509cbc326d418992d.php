<?php if(Session::has('message')!= null): ?>
   <div class="alert alert-success"><?php echo e(Session::get('message')); ?><span>X</span></div>
<?php endif; ?>
<?php if(Session::has('success')!= null): ?>
   <div class="alert <?php echo e(Session::get('alert-class', 'alert-info')); ?>"><?php echo e(Session::get('success')); ?><span>X</span></div>
<?php endif; ?>
<?php if(Session::has('error')!= null): ?>
   <div class="alert <?php echo e(Session::get('alert-class', 'alert-info')); ?>"><?php echo e(Session::get('error')); ?><span>X</span></div>
<?php endif; ?>
<?php if(!isset($errors)): ?>
<div class="alert alert-danger"><?php foreach($errors->all() as $error){ echo $error."<br>"; } ?><span>X</span></div>
<?php endif; ?>
