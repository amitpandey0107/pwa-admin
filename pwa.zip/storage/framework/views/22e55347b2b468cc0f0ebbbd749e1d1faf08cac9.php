<?php $__env->startSection('admin::content'); ?>
<!-- End Navbar -->
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                <div class="card">
                    <div class="card-header card-header-success card-header-icon">
                        <div class="card-icon">
                            <i class="material-icons">menu_book</i>
                        </div>
                        <h4 class="card-title">CMS Page <?php if($slug): ?> Edit <?php else: ?> Add <?php endif; ?>
                            <a href="<?php echo e(route('cms-page-list')); ?>">
                                <button class="btn btn-success" style="float:right">Back</button>
                            </a>
                        </h4>
                    </div>                    
                    <div class="card-body">
                        <div class="panel-group">
                            <div class="panel panel-default">
                            <div class="panel-collapse">
                                <div class="panel-body">
                                    <form method="POST" action="<?php echo e(route('cms-page-add-edit')); ?>" id="validate" enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" value="<?php echo e($slug); ?>" name="slug"/>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                <label class="bmd-label-floating">Title </label>
                                                <input type="text" class="form-control required" title="Title field is required." name="title" value="<?php echo e(isset($page->title) ? $page->title : ''); ?>">
                                                <?php if($errors->has('title')): ?>
                                                    <span class="error" role="alert">
                                                        <strong><?php echo e($errors->first('title')); ?></strong>
                                                    </span>
                                                <?php endif; ?>

                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                <textarea id="textarea" name="body" class="required" placeholder="body"><?php echo e(isset($page->body) ? $page->body : ''); ?></textarea>
                                                <?php if($errors->has('body')): ?>
                                                    <span class="error" role="alert">
                                                        <strong><?php echo e($errors->first('body')); ?></strong>
                                                    </span>
                                                <?php endif; ?>

                                                </div>
                                            </div>

                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <div class="dropdown show-tick">
                                                        <select class="w-100 selectpicker required" name="status" data-style="select-with-transition">
                                                            <option value="1" <?php if(!empty($page)){ if( $page->status == '1'){ echo 'selected'; } } ?>>Active</option>
                                                            <option value="0" <?php if(!empty($page)){ if( $page->status == '0'){ echo 'selected'; } } ?>>Deactive</option>
                                                        </select>
                                                        <div class="dropdown-menu " role="combobox">
                                                            <div class="inner show" role="listbox" aria-expanded="false" tabindex="-1">
                                                                <ul class="dropdown-menu inner show"></ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <?php if($errors->has('status')): ?>
                                                        <span class="error" role="alert">
                                                            <strong><?php echo e($errors->first('status')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            

                                            <button type="submit" class="btn btn-success pull-right">
                                                <?php if($slug): ?> Update <?php else: ?> Save <?php endif; ?> 
                                                <div class="ripple-container"></div>
                                            </button>
                                        </div>
                                        <div class="clearfix"></div>
                                    </form>
                                </div>
                            </div>
                            </div>
                        </div>

                    </div>
                </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('admin::custom_js'); ?>
    <script src="/vendor/unisharp/laravel-ckeditor/ckeditor.js"></script>
    <script src="/vendor/unisharp/laravel-ckeditor/adapters/jquery.js"></script>

    <script>
        CKEDITOR.config.image_previewText = CKEDITOR.tools.repeat(' ',1);
        CKEDITOR.replace('body', {
            filebrowserUploadUrl: "<?php echo e(route('ckeditor-upload', ['_token' => csrf_token() ])); ?>",
            filebrowserUploadMethod: 'form',
        });
        $( document ).ready( function () {
            $( '#validate' ).validate();
        });
    </script>
    <?php $__env->stopSection(); ?>   

<?php echo $__env->make('admin::layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>