<?php $__env->startSection('admin::title', 'Category'); ?>

<?php $__env->startSection('admin::pagetitle', 'Edit Category'); ?>

<?php $__env->startSection('admin::content'); ?>

<style>
.statchk .form-check-label {margin-top: 14px;}
.imgmt{margin-top: 20px;}
.form-group input[type=file] {opacity: 1; position: relative; z-index: 0; }
select#product_subcateory {border: none; border-bottom: 1px solid #ccc; width: 27%; color: #999; position:relative;}
</style>

<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-12">
				<?php if(count($errors) > 0): ?>
			       <div class = "alert alert-danger">
			          <ul>
			             <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			                <li><?php echo e($error); ?></li>
			             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			          </ul>
			       </div>
			    <?php endif; ?>

			    <?php if(!empty($successMsg)): ?>
			      <div class="alert alert-success"> <?php echo e($successMsg); ?></div>
			    <?php endif; ?>
			</div>
		</div>

		<div class="row">
			<div class="col-sm-12">
				<?php if(session()->has('success')): ?>
					<?php $__env->startSection('admin::custom_js'); ?>
					<script>
						Swal.fire({
						  position: 'center',
						  type: 'success',
						  title: " <?php echo e(session()->get('success')); ?> ",
						  showConfirmButton: false,
						  timer: 3000
						})
					</script>
					<?php $__env->stopSection(); ?>
				<?php endif; ?>

				<?php if(session()->has('error')): ?>
					<?php $__env->startSection('admin::custom_js'); ?>
					<script>
						Swal.fire({
						  position: 'center',
						  type: 'error',
						  title: " <?php echo e(session()->get('error')); ?> ",
						  showConfirmButton: false,
						  timer: 3000
						})
					</script>
					<?php $__env->stopSection(); ?>
				<?php endif; ?>
			</div>
		</div>
	</div>

	<div class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-sm-12 text-right">
					<a href="<?php echo e(route('categories')); ?>" class="btn btn-primary">
						 Back
					</a>
				</div>
				<div class="col-md-12">

				    <div class="card ">
				        <div class="card-header card-header-rose card-header-text">
				            <div class="card-text">
				                <h4 class="card-title">Category Form</h4>
				            </div>
				        </div>
				        <div class="card-body">
				            	<?php echo e(Form::open(array('url' => url('admin/category-edit'), 'method'=>'post', 'class'=>'form-horizontal', 'id'=>'addcategory', 'enctype'=>'multipart/form-data'))); ?>

											<?php echo csrf_field(); ?>



											<div class="row">
				                	<div class="col-sm-2 col-form-label">
				                     	<label for="parent_category" class="bmd-label-floating"> Select Category *</label>
				                    </div>
				                    <div class="col-sm-10">
				                        <div class="form-group bmd-form-group">
																	<select class="selectpicker" data-style="select-with-transition" data-size="7" autocomplete="off" name="parent_category" id="parent_category" required>
					                            <option value="0">Choose Category</option>
					                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																				<?php if($data->id == $category->parent_category ): ?>
					                            	<option value="<?php echo e($data->id); ?>" selected> <?php echo e($data->category_name); ?> </option>
																				<?php else: ?>
																				<option value="<?php echo e($data->id); ?>"> <?php echo e($data->category_name); ?> </option>
																				<?php endif; ?>
					                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				                         	</select>
				                          	<?php if($errors->has('parent_category')): ?>
																		<span class="error" role="parent_category">
																			<strong><?php echo e($errors->first('parent_category')); ?></strong>
																		</span>
																		<?php endif; ?>
				                        </div>
				                    </div>
				                </div>

												<div class="row">
				                	<div class="col-sm-2 col-form-label">
				                     	<label for="category_name" class="bmd-label-floating"> Category Name *</label>
				                     </div>
				                    <div class="col-sm-10">
				                        <div class="form-group bmd-form-group">
				                            <input type="text" name="category_name" id="category_name" class="form-control" autocomplete="off"  value="<?php echo e($category->category_name); ?>" required>
				                            <?php if($errors->has('category_name')): ?>
																			<span class="error" role="category_name">
																				<strong><?php echo e($errors->first('category_name')); ?></strong>
																			</span>
																		<?php endif; ?>
				                        </div>
				                    </div>
				                </div>

				                <div class="row">
				                    <div class="col-sm-2 col-form-label">
															<div class="card-footer ">
																<input type="hidden" name="id" value="<?php echo e($category->id); ?>">
						                  	<button type="submit" class="btn btn-fill btn-rose">Update<div class="ripple-container"></div></button>
						                	</div>
				                    </div>
				                </div>

										<?php echo e(Form::close()); ?>

				            <!-- </form> -->
				        </div>
				    </div>
					<!-- /card -->

				</div>
			</div>
			<!-- /row -->
		</div>
		<!-- /container-fluid -->
	</div>
	<!-- /content -->
</div>
<!-- content -->

<?php $__env->stopSection(); ?>


<?php $__env->startSection('admin::custom_js'); ?>

<script type="text/javascript">
$(document).ready(function () {
	$('#addcategory').validate();
});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin::layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>