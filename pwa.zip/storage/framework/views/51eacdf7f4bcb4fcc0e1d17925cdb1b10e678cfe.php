<?php $__env->startSection('admin::title', 'Leads'); ?>

<?php $__env->startSection('admin::pagetitle', 'Add Lead'); ?>

<?php $__env->startSection('admin::content'); ?>

<style>
.statchk .form-check-label {margin-top: 14px;}
.imgmt{margin-top: 20px;}
.form-group input[type=file] {opacity: 1; position: relative; z-index: 0; }
select#product_subcateory {border: none; border-bottom: 1px solid #ccc; width: 27%; color: #999; position:relative;}
</style>

<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-12">
				<?php if(count($errors) > 0): ?>
			       <div class = "alert alert-danger">
			          <ul>
			             <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			                <li><?php echo e($error); ?></li>
			             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			          </ul>
			       </div>
			    <?php endif; ?>

			    <?php if(!empty($successMsg)): ?>
			      <div class="alert alert-success"> <?php echo e($successMsg); ?></div>
			    <?php endif; ?>
			</div>
		</div>

		<div class="row">
			<div class="col-sm-12">
				<?php if(session()->has('success')): ?>
					<?php $__env->startSection('admin::custom_js'); ?>
					<script>
						Swal.fire({
						  position: 'center',
						  type: 'success',
						  title: " <?php echo e(session()->get('success')); ?> ",
						  showConfirmButton: false,
						  timer: 3000
						})
					</script>
					<?php $__env->stopSection(); ?>
				<?php endif; ?>

				<?php if(session()->has('error')): ?>
					<?php $__env->startSection('admin::custom_js'); ?>
					<script>
						Swal.fire({
						  position: 'center',
						  type: 'error',
						  title: " <?php echo e(session()->get('error')); ?> ",
						  showConfirmButton: false,
						  timer: 3000
						})
					</script>
					<?php $__env->stopSection(); ?>
				<?php endif; ?>

			</div>
		</div>
	</div>

	<div class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-sm-12 text-right">
					<a href="<?php echo e(route('leads')); ?>" class="btn btn-primary">
						 Back
					</a>
				</div>
				<div class="col-md-12">

				    <div class="card ">
				        <div class="card-header card-header-rose card-header-text">
				            <div class="card-text">
				                <h4 class="card-title">Add Lead</h4>
				            </div>
				        </div>
				        <div class="card-body">
				            	<?php echo e(Form::open(array('url' => url('admin/lead-add'), 'method'=>'post', 'class'=>'form-horizontal', 'id'=>'addLead', 'enctype'=>'multipart/form-data'))); ?>

											<?php echo csrf_field(); ?>


											<div class="row">
				                	<div class="col-sm-2 col-form-label">
				                     	<label for="farm_id" class="bmd-label-floating"> Select Farm *</label>
				                    </div>
				                    <div class="col-sm-10">
				                        <div class="form-group bmd-form-group">
																	<select class="selectpicker" data-style="select-with-transition" data-size="7" autocomplete="off" name="farm_id" id="farm_id" required>
					                            <option value="">Choose Farm</option>
					                            <?php $__currentLoopData = $farms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					                            	<option value="<?php echo e($data->id); ?>"> <?php echo e($data->farm_name); ?> </option>
					                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				                         	</select>
				                          	<?php if($errors->has('farm_id')): ?>
																		<span class="error" role="farm_id">
																			<strong><?php echo e($errors->first('farm_id')); ?></strong>
																		</span>
																		<?php endif; ?>
				                        </div>
				                    </div>
				                </div>

											<div class="row">
				                	<div class="col-sm-2 col-form-label">
				                     	<label for="user_id" class="bmd-label-floating"> Select User *</label>
				                    </div>
				                    <div class="col-sm-10">
				                        <div class="form-group bmd-form-group">
																	<select class="selectpicker" data-style="select-with-transition" data-size="7" autocomplete="off" name="user_id" id="user_id" required>
					                            <option value="">Choose User</option>
					                            <?php $__currentLoopData = $userArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					                            	<option value="<?php echo e($key); ?>"> <?php echo e($cat); ?> </option>
					                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				                         	</select>
				                          	<?php if($errors->has('user_id')): ?>
																		<span class="error" role="user_id">
																			<strong><?php echo e($errors->first('user_id')); ?></strong>
																		</span>
																		<?php endif; ?>
				                        </div>
				                    </div>
				                </div>

												<!-- <div class="row">
				                	<div class="col-sm-2 col-form-label">
				                     	<label for="consultant_id" class="bmd-label-floating"> Select Consultant *</label>
				                    </div>
				                    <div class="col-sm-10">
				                        <div class="form-group bmd-form-group">
																	<select class="selectpicker" data-style="select-with-transition" data-size="7" autocomplete="off" name="consultant_id" id="consultant_id" required>
					                            <option value="">Choose Consultant</option>
					                            <?php $__currentLoopData = $consultantArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					                            	<option value="<?php echo e($key); ?>"> <?php echo e($cat); ?> </option>
					                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				                         	</select>
				                          	<?php if($errors->has('consultant_id')): ?>
																		<span class="error" role="consultant_id">
																			<strong><?php echo e($errors->first('consultant_id')); ?></strong>
																		</span>
																		<?php endif; ?>
				                        </div>
				                    </div>
				                </div> -->

												<div class="row">
				                	<div class="col-sm-2 col-form-label">
				                     	<label for="service_id" class="bmd-label-floating"> Choose Category/Service *</label>
				                    </div>
				                    <div class="col-sm-10">
				                        <div class="form-group bmd-form-group">
																	<select class="selectpicker" data-style="select-with-transition" data-size="7" autocomplete="off" name="service_id" id="service_id" required>
					                            <option value="">Choose Service</option>
					                            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					                            	<option value="<?php echo e($data->id); ?>"> <?php echo e($data->service_name); ?> </option>
					                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				                         	</select>
				                          	<?php if($errors->has('service_id')): ?>
																		<span class="error" role="service_id">
																			<strong><?php echo e($errors->first('service_id')); ?></strong>
																		</span>
																		<?php endif; ?>
				                        </div>
				                    </div>
				                </div>

				                <div class="row">
				                	<div class="col-sm-2 col-form-label">
				                     	<label for="alt_contact_number" class="bmd-label-floating"> Alternate Contact Number*</label>
				                     </div>
				                    <div class="col-sm-10">
				                        <div class="form-group bmd-form-group">
				                            <input type="text" name="alt_contact_number" id="alt_contact_number" class="form-control" autocomplete="off"  value="<?php echo e(old('alt_contact_number')); ?>" required>
				                            <?php if($errors->has('alt_contact_number')): ?>
																			<span class="error" role="alt_contact_number">
																				<strong><?php echo e($errors->first('alt_contact_number')); ?></strong>
																			</span>
																		<?php endif; ?>
				                        </div>
				                    </div>
				                </div>

												<div class="row">
				                	<div class="col-sm-2 col-form-label">
				                     	<label for="information" class="bmd-label-floating">Problem write your problem here*</label>
				                     </div>
				                    <div class="col-sm-10">
				                        <div class="form-group bmd-form-group">
				                            <textarea name="information" id="information" cols="30" rows="10" class="form-control" autocomplete="off"  value="<?php echo e(old('information')); ?>" required></textarea>
				                            <?php if($errors->has('information')): ?>
																			<span class="error" role="information">
																				<strong><?php echo e($errors->first('information')); ?></strong>
																			</span>
																		<?php endif; ?>
				                        </div>
				                    </div>
				                </div>

				                <div class="row">
				                    <div class="col-sm-2 col-form-label">
															<div class="card-footer ">
						                  	<button type="submit" class="btn btn-fill btn-rose">Submit<div class="ripple-container"></div></button>
						                	</div>
				                    </div>
				                </div>

										<?php echo e(Form::close()); ?>

				            <!-- </form> -->
				        </div>
				    </div>
					<!-- /card -->

				</div>
			</div>
			<!-- /row -->
		</div>
		<!-- /container-fluid -->
	</div>
	<!-- /content -->
</div>
<!-- content -->

<?php $__env->stopSection(); ?>


<?php $__env->startSection('admin::custom_js'); ?>

<script type="text/javascript">
$(document).ready(function () {
	$('#addLead').validate();
});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin::layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>