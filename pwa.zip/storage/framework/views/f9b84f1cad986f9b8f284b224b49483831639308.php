<?php $urlName = Request::segment(2); ?>
<div class="sidebar" data-color="rose" data-background-color="black" data-image="<?php echo e(asset('img/sidebar-1.jpg')); ?>">
    <div class="logo">
        <a href="javacript:void(0)" class="simple-text logo-mini">
            <img src="<?php echo e(asset('images/favicon-32x32.png')); ?>"/>
        </a>
        <a href="<?php echo e(route('dashboard')); ?>" class="simple-text logo-normal">
            SISU
        </a>
    </div>
    <div class="sidebar-wrapper">
        <ul class="nav">
            <li class="nav-item <?php //if($urlName == '/' || $urlName == 'dashboard'){ echo "active"; }     ?>">
                <a class="nav-link" href="">
                    <i class="material-icons">dashboard</i>
                    <p> Dashboard </p>
                </a>
            </li>          
        </ul>
    </div>
</div>
