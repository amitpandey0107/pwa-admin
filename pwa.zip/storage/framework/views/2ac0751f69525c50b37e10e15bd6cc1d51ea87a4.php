<?php $__env->startSection('admin::title', 'Customer'); ?>

<?php $__env->startSection('admin::pagetitle', 'Customer Details'); ?>

<?php $__env->startSection('admin::content'); ?>

<style>
    .statchk .form-check-label {margin-top: 14px;}
    .imgmt{margin-top: 20px;}
</style>

<div class="content">

    <div class="content">
        <div class="container-fluid">

            <div class="row">
                <div class="col-sm-12">
                    <?php if(count($errors) > 0): ?>
                    <div class = "alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <?php endif; ?>

                    <?php if(!empty($successMsg)): ?>
                    <div class="alert alert-success"> <?php echo e($successMsg); ?></div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="row">
                
                <div class="col-md-12">

                    <div class="card ">
                    <div class="card-header card-header-success card-header-icon">
                            <div class="card-icon">
                                <i class="material-icons">assignment</i>
                            </div>
                            <h4 class="card-title">Customer Details
                                <a href="<?php echo e(route('customers')); ?>">
                                    <button class="btn btn-success" style="float:right">Back</button>
                                </a>
                            </h4>
                        </div>
                        <div class="card-body ">
                        <form method="POST" class="form-horizontal" id="customerForm" enctype="multipart/form-data" action="<?php echo e(route('customer-edit')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-sm-2 col-form-label">
                                        <label for="name" class="bmd-label-floating"> Name *</label>
                                    </div>	
                                    <div class="col-sm-10">
                                        <div class="form-group bmd-form-group">
                                            <input disabled type="text" name="name" id="firstname" class="form-control required" autocomplete="off" value="<?php echo e($user->name); ?>">
                                            <?php if($errors->has('name')): ?>
                                            <span class="error" role="name">
                                                <strong><?php echo e($errors->first('name')); ?></strong>
                                            </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <label class="col-sm-2 col-form-label">Email *</label>
                                    <div class="col-sm-10">
                                        <div class="form-group bmd-form-group">
                                            <input disabled type="text" name="email" id="email" class="form-control required email" autocomplete="off" value="<?php echo e($user->email); ?>">
                                            <?php if($errors->has('email')): ?>
                                            <span class="error" role="email">
                                                <strong><?php echo e($errors->first('email')); ?></strong>
                                            </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <label class="col-sm-2 col-form-label">Phone *</label>
                                    <div class="col-sm-10">
                                        <div class="form-group bmd-form-group">
                                            <input disabled type="text" name="mobile_number" id="phone" maxlength="12" class="form-control required number" autocomplete="off" value="<?php echo e($user->mobile_number); ?>">
                                            <?php if($errors->has('mobile_number')): ?>
                                            <span class="error" role="mobile_number">
                                                <strong><?php echo e($errors->first('mobile_number')); ?></strong>
                                            </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <label class="col-sm-2 col-form-label">Date of Birth *</label>
                                    <div class="col-sm-10">
                                        <div class="form-group bmd-form-group is-filled">
                                            <input disabled type="text" class="form-control datepicker required" autocomplete="off" name="date_of_birth" id="dob" value="<?php echo e($user->date_of_birth); ?>">
                                            <?php if($errors->has('date_of_birth')): ?>
                                            <span class="error" role="date_of_birth">
                                                <strong><?php echo e($errors->first('date_of_birth')); ?></strong>
                                            </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <label class="col-sm-2 col-form-label label-checkbox">Gender *</label>
                                    <div class="col-sm-10 checkbox-radios">
                                        <div class="form-check form-check-inline">
                                           <?php echo e($user->gender); ?>

                                        </div>
                                    </div>
                                </div>

                                
                            </form> 
                        </div>
                    </div>
                    <!-- /card -->

                </div>
            </div>
            <!-- /row -->
        </div>
        <!-- /container-fluid -->
    </div>
    <!-- /content -->
</div>
<!-- content -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('admin::custom_js'); ?>
<script type="text/javascript">
    $(document).ready(function () {
        $('#customerForm').validate();
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin::layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>