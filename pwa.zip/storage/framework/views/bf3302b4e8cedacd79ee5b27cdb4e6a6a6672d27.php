<?php $__env->startSection('admin::title', 'Consultants'); ?>

<?php $__env->startSection('admin::pagetitle', 'Consultants Details'); ?>

<?php $__env->startSection('admin::content'); ?>

<style>
    .statchk .form-check-label {margin-top: 14px;}
    .imgmt{margin-top: 20px;}
</style>

<div class="content">

    <div class="content">
        <div class="container-fluid">

            <div class="row">
                <div class="col-sm-12">
                    <?php if(count($errors) > 0): ?>
                    <div class = "alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <?php endif; ?>

                    <?php if(!empty($successMsg)): ?>
                    <div class="alert alert-success"> <?php echo e($successMsg); ?></div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="row">
                <div class="col-sm-12 text-right">
                    <a href="<?php echo e(route('consultants')); ?>" class="btn btn-primary">
                        Back
                    </a>
                </div>
                <div class="col-md-12">

                    <div class="card ">
                        <div class="card-header card-header-rose card-header-text">
                            <div class="card-text">
                                <h4 class="card-title">Consultants Details</h4>
                            </div>
                        </div>
                        <div class="card-body ">
                            <form method="POST" class="form-horizontal" id="consultantForm" enctype="multipart/form-data" action="<?php echo e(route('consultant-edit')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-sm-2 col-form-label">
                                        <label for="name" class="bmd-label-floating"> Name </label>
                                    </div>	
                                    <div class="col-sm-10">
                                        <div class="form-group bmd-form-group">
                                            <strong class="form-control"><?php echo e($user->name); ?></strong>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <label class="col-sm-2 col-form-label">Email</label>
                                    <div class="col-sm-10">
                                        <div class="form-group bmd-form-group">
                                            <strong class="form-control"><?php echo e($user->email); ?></strong>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <label class="col-sm-2 col-form-label">Phone</label>

                                    <div class="col-sm-10">
                                        <div class="form-group bmd-form-group">
                                            <strong class="form-control"><?php echo e($user->mobile_number); ?></strong>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <label class="col-sm-2 col-form-label">Date of Birth</label>

                                    <div class="col-sm-10">
                                        <div class="form-group bmd-form-group">
                                            <strong class="form-control"><?php echo e($user->date_of_birth); ?></strong>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <label class="col-sm-2 col-form-label label-checkbox">Gender</label>
                                    <div class="col-sm-10">
                                        <div class="form-group bmd-form-group">
                                            <strong class="form-control"><?php echo e($user->gender); ?></strong>
                                        </div>
                                    </div>
                                </div>
                            </form> 
                        </div>
                    </div>
                    <!-- /card -->

                </div>
            </div>
            <!-- /row -->
        </div>
        <!-- /container-fluid -->
    </div>
    <!-- /content -->
</div>
<!-- content -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('admin::custom_js'); ?>
<script type="text/javascript">
    $(document).ready(function () {
        $('#consultantForm').validate();
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin::layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>