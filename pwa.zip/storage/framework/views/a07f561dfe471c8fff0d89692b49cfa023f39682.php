<?php $__env->startSection('admin::title', 'Post'); ?>

<?php $__env->startSection('admin::content'); ?>

<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12 text-right">
            </div>
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header card-header-success card-header-icon">
                        <div class="card-icon">
                            <i class="material-icons">assignment</i>
                        </div>
                        <h4 class="card-title">
                            Post List
                            <a href="<?php echo e(route('post-add')); ?>" class="btn btn-success" style="float:right;">
                                <i class="material-icons">add</i> Add Post
                            </a>
                        </h4>
                    </div>
                    <div class="card-body">
                        <div class="toolbar"></div>
                        <div class="material-datatables">
                            <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Desc</th>
                                        <th>Category</th>
                                        <th>Image</th>                  
                                        <th class="disabled-sorting text-right">Actions</th>
                                    </tr>
                                </thead>
                                <tfoot>                                    
                                    <tr>
                                        <th>Name</th>
                                        <th>Desc</th>
                                        <th>Category</th>
                                        <th>Image</th>                  
                                        <th class="text-right">Actions</th>
                                    </tr>
                                </tfoot>
                                <tbody>
                                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   
                                    <tr>
                                        <td><?php echo e($data->title); ?></td>
                                        <td><?php echo e($data->description); ?></td>
                                        <td><?php echo e($data->category); ?></td>

                                        <?php if($data->image): ?>
                                        <td><img src="<?php echo e(asset('/uploads/posts/'.$data->image)); ?>" class="imageClass" title="Flag image" height="60"> </td>
                                        <?php else: ?>
                                        <td><img src="https://cdn0.iconfinder.com/data/icons/famous-character-vol-2-colored/48/JD-04-256.png" class="imageClass" title="Flag image" height="60"> </td>
                                        <?php endif; ?>

                                        <!-- <td>
                                            <a href="" class="actions">
                                                <button type="button" title="Edit" rel="tooltip" class="btn btn-success" data-original-title="" title="">
                                                    <i class="material-icons">edit</i>
                                                    <div class="ripple-container"></div>
                                                </button>
                                            </a>
                                        </td> -->
                                    </tr>    
                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                           
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- end content-->
                </div>
                <!--  end card  -->
            </div>
            <!-- end col-md-12 -->
        </div>
        <!-- end row -->
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('admin::custom_js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin::layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>