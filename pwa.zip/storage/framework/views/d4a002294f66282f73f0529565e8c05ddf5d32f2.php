<?php $__env->startSection('admin::custom_css'); ?>
<style>
    .switch {
      position: relative;
      display: inline-block;
      width: 60px;
      height: 34px;
    }

    .switch input {
      opacity: 0;
      width: 0;
      height: 0;
    }

    .slider {
      position: absolute;
      cursor: pointer;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background-color: #ccc;
      -webkit-transition: .4s;
      transition: .4s;
    }

    .slider:before {
      position: absolute;
      content: "";
      height: 26px;
      width: 26px;
      left: 4px;
      bottom: 4px;
      background-color: white;
      -webkit-transition: .4s;
      transition: .4s;
    }

    input:checked + .slider {
      background-color: #2196F3;
    }

    input:focus + .slider {
      box-shadow: 0 0 1px #2196F3;
    }

    input:checked + .slider:before {
      -webkit-transform: translateX(26px);
      -ms-transform: translateX(26px);
      transform: translateX(26px);
    }

    /* Rounded sliders */
    .slider.round {
      border-radius: 34px;
    }

    .slider.round:before {
      border-radius: 50%;
    }
    </style>
    <?php $__env->stopSection(); ?>
<?php $__env->startSection('admin::content'); ?>
      <div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-primary card-header-icon">
                  <div class="card-icon">
                    <i class="material-icons">assignment</i>
                  </div>
                  <h4 class="card-title">CMS List
                        <a href="<?php echo e(route('cms-page-view')); ?>">
                            <button class="btn btn-primary" style="float:right"><i class="material-icons">add</i> Add CMS</button>
                        </a>
                  </h4>
                </div>
                <div class="card-body">
                  <div class="toolbar">
                    <!--        Here you can write extra buttons/actions for the toolbar              -->
                  </div>
                  <div class="material-datatables">
                    <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
                      <thead>
                        <tr>
                          <th>Title</th>
                          <th>Body</th>
                          <th>Status</th>
                          <th class="disabled-sorting text-right">Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php $__currentLoopData = $page; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($data->title); ?></td>
                            <td>
                                <?php 
                                $string = strip_tags($data->body);
                                if (strlen($string) > 400) {
                                    $stringCut = substr($string, 0, 400);
                                    $endPoint = strrpos($stringCut, ' ');
                                    $string = $endPoint? substr($stringCut, 0, $endPoint) : substr($stringCut, 0);
                                }
                                echo $string.'...';
                                ?>
                            </td>
                            <td>
                                <?php if($data->status == 1): ?> 
                                    <a onclick="updateStatus('<?php echo e(route('cms-page-status', $data->slug.'_0')); ?>')" class="btn btn-success">Active</a> 
                                <?php else: ?> 
                                    <a  onclick="updateStatus('<?php echo e(route('cms-page-status', $data->slug.'_1')); ?>')" class="btn btn-danger">Deactive</a> 
                                <?php endif; ?> 
                            </td>

                            <td class="td-actions text-right">
                                <a href="javascript:void(0);" onclick='GetAction("<?php echo e(url('admin/cms-page-delete', [$data->slug])); ?>")'  class="actions">
                                  <button type="button" rel="tooltip" class="btn btn-danger" data-original-title="" title="">
                                    <i class="material-icons">restore_from_trash</i>
                                    <div class="ripple-container"></div>
                                  </button>
                                </a>
                                <a href="<?php echo e(url('admin/cms-page-view/'.$data->slug)); ?>" class="actions">
                                    <button type="button" rel="tooltip" class="btn btn-info" data-original-title="" title="">
                                        <i class="material-icons">visibility</i>
                                        <div class="ripple-container"></div>
                                    </button>
                                </a>
                            </td>
                          </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
        </div>
    </div>
 </div>
      <?php $__env->stopSection(); ?>
      <?php $__env->startSection('admin::custom_js'); ?>
      <?php $path = asset("assets/images/favicon-32x32.png"); ?>
      <script>
         function GetAction(param) {
            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to perform this action? This action cannot be undone.",
                type: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                    if (result.value) {
                        Swal.fire(
                            'Deleted!',
                            'Education has been deleted.',
                            'success'
                        )
                        window.location = param
                    }
            })
        }



        function updateStatus(param) {
            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to perform this action.",
                type: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, Update it!'
                }).then((result) => {
                    if (result.value) {
                        Swal.fire(
                            'Updated!',
                            'Education status updated.',
                            'success'
                        )
                        window.location = param
                    }
            })
        }

          $(document).ready(function() {
            $('#datatables').DataTable({
              "pagingType": "full_numbers",
              "lengthMenu": [
                [10, 25, 50, -1],
                [10, 25, 50, "All"]
              ],
              responsive: true,
              language: {
                search: "_INPUT_",
                searchPlaceholder: "Search records",
              }
            });

            var table = $('#datatable').DataTable();

            // Edit record
            table.on('click', '.edit', function() {
              $tr = $(this).closest('tr');
              var data = table.row($tr).data();
              alert('You press on Row: ' + data[0] + ' ' + data[1] + ' ' + data[2] + '\'s row.');
            });

            // Delete a record
            table.on('click', '.remove', function(e) {
              $tr = $(this).closest('tr');
              table.row($tr).remove().draw();
              e.preventDefault();
            });

            //Like record
            table.on('click', '.like', function() {
              alert('You clicked on Like button');
            });
          });
      </script>
      <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin::layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>