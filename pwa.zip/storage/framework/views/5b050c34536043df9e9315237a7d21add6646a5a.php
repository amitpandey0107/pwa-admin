
<meta charset="utf-8" />
<link rel="icon" type="image/png" href="<?php echo e(asset('img/favicon.png')); ?>" sizes="32x32" />
<link rel="icon" type="image/png" href="<?php echo e(asset('img/favicon.png')); ?>" sizes="16x16" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<title>
    Farmer
</title>
