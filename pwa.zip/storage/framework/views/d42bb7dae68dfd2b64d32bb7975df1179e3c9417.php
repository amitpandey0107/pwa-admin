<?php $__env->startSection('admin::title', 'Leads'); ?>

<?php $__env->startSection('admin::pagetitle', 'Edit Lead'); ?>

<?php $__env->startSection('admin::content'); ?>

<style>
.statchk .form-check-label {margin-top: 14px;}
.imgmt{margin-top: 20px;}
.form-group input[type=file] {opacity: 1; position: relative; z-index: 0; }
select#product_subcateory {border: none; border-bottom: 1px solid #ccc; width: 27%; color: #999; position:relative;}
</style>

<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-12">
				<?php if(count($errors) > 0): ?>
			       <div class = "alert alert-danger">
			          <ul>
			             <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			                <li><?php echo e($error); ?></li>
			             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			          </ul>
			       </div>
			    <?php endif; ?>

			    <?php if(!empty($successMsg)): ?>
			      <div class="alert alert-success"> <?php echo e($successMsg); ?></div>
			    <?php endif; ?>
			</div>
		</div>

		<div class="row">
			<div class="col-sm-12">
				<?php if(session()->has('success')): ?>
					<?php $__env->startSection('admin::custom_js'); ?>
					<script>
						Swal.fire({
						  position: 'center',
						  type: 'success',
						  title: " <?php echo e(session()->get('success')); ?> ",
						  showConfirmButton: false,
						  timer: 3000
						})
					</script>
					<?php $__env->stopSection(); ?>
				<?php endif; ?>

				<?php if(session()->has('error')): ?>
					<?php $__env->startSection('admin::custom_js'); ?>
					<script>
						Swal.fire({
						  position: 'center',
						  type: 'error',
						  title: " <?php echo e(session()->get('error')); ?> ",
						  showConfirmButton: false,
						  timer: 3000
						})
					</script>
					<?php $__env->stopSection(); ?>
				<?php endif; ?>

			</div>
		</div>
	</div>

	<div class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">

				    <div class="card ">
							<div class="card-header card-header-success card-header-icon">
											<div class="card-icon">
													<i class="material-icons">assignment</i>
											</div>
											<h4 class="card-title">Lead Edit
													<a href="<?php echo e(route('leads')); ?>">
															<button class="btn btn-success" style="float:right">Back</button>
													</a>
											</h4>
									</div>
				        <div class="card-body">
				            	<?php echo e(Form::open(array('url' => url('admin/lead-edit'), 'method'=>'post', 'class'=>'form-horizontal', 'id'=>'editLead', 'enctype'=>'multipart/form-data'))); ?>

											<?php echo csrf_field(); ?>


											<div class="row">
				                	<div class="col-sm-2 col-form-label">
				                     	<label for="farm_id" class="bmd-label-floating"> Farm *</label>
				                    </div>
				                    <div class="col-sm-10">
				                        <div class="form-group bmd-form-group">
																	<select disabled class="selectpicker" data-style="select-with-transition" data-size="7" autocomplete="off" name="farm_id" id="farm_id" required>
					                            <option value="">Choose Farm</option>
					                            <?php $__currentLoopData = $farms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																				<?php if($data->id == $leads->farm_id): ?>
					                            	<option value="<?php echo e($data->id); ?>" selected> <?php echo e($data->farm_name); ?> </option>
																				<?php else: ?>
																				<option value="<?php echo e($data->id); ?>"> <?php echo e($data->farm_name); ?> </option>
																				<?php endif; ?>
					                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				                         	</select>
				                          	<?php if($errors->has('farm_id')): ?>
																		<span class="error" role="farm_id">
																			<strong><?php echo e($errors->first('farm_id')); ?></strong>
																		</span>
																		<?php endif; ?>
				                        </div>
				                    </div>
				                </div>

											<div class="row">
				                	<div class="col-sm-2 col-form-label">
				                     	<label for="user_id" class="bmd-label-floating"> User *</label>
				                    </div>
				                    <div class="col-sm-10">
				                        <div class="form-group bmd-form-group">
																	<select disabled class="selectpicker" data-style="select-with-transition" data-size="7" autocomplete="off" name="user_id" id="user_id" required>
					                            <option value="">Choose User</option>
					                            <?php $__currentLoopData = $userArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																				<?php if($key == $leads->user_id): ?>
					                            	<option value="<?php echo e($key); ?>" selected> <?php echo e($cat); ?> </option>
																				<?php else: ?>
																				<option value="<?php echo e($key); ?>"> <?php echo e($cat); ?> </option>
																				<?php endif; ?>
					                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				                         	</select>
				                          	<?php if($errors->has('user_id')): ?>
																		<span class="error" role="user_id">
																			<strong><?php echo e($errors->first('user_id')); ?></strong>
																		</span>
																		<?php endif; ?>
				                        </div>
				                    </div>
				                </div>

												<div class="row">
				                	<div class="col-sm-2 col-form-label">
				                     	<label for="consultant_id" class="bmd-label-floating"> Assign Consultant *</label>
				                    </div>
				                    <div class="col-sm-10">
				                        <div class="form-group bmd-form-group">
																	<select class="selectpicker" data-style="select-with-transition" data-size="7" autocomplete="off" name="consultant_id" id="consultant_id">
					                            <option value="">Choose Consultant</option>
					                            <?php $__currentLoopData = $consultantArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																				<?php if($key==$leads->consultant_id): ?>
					                            	<option value="<?php echo e($key); ?>" selected> <?php echo e($cat); ?> </option>
																				<?php else: ?>
																				<option value="<?php echo e($key); ?>"> <?php echo e($cat); ?> </option>
																				<?php endif; ?>
					                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				                         	</select>
				                          	<?php if($errors->has('consultant_id')): ?>
																		<span class="error" role="consultant_id">
																			<strong><?php echo e($errors->first('consultant_id')); ?></strong>
																		</span>
																		<?php endif; ?>
				                        </div>
				                    </div>
				                </div>

												<div class="row">
				                	<div class="col-sm-2 col-form-label">
				                     	<label for="service_id" class="bmd-label-floating"> Category/Service *</label>
				                    </div>
				                    <div class="col-sm-10">
				                        <div class="form-group bmd-form-group">
																	<select disabled class="selectpicker" data-style="select-with-transition" data-size="7" autocomplete="off" name="service_id" id="service_id" required>
					                            <option value="">Choose Service</option>
					                            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																				<?php if($data->id == $leads->service_id): ?>
					                            	<option value="<?php echo e($data->id); ?>" selected> <?php echo e($data->service_name); ?> </option>
																				<?php else: ?>
																				<option value="<?php echo e($data->id); ?>"> <?php echo e($data->service_name); ?> </option>
																				<?php endif; ?>
					                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				                         	</select>
				                          	<?php if($errors->has('service_id')): ?>
																		<span class="error" role="service_id">
																			<strong><?php echo e($errors->first('service_id')); ?></strong>
																		</span>
																		<?php endif; ?>
				                        </div>
				                    </div>
				                </div>

				                <div class="row">
				                	<div class="col-sm-2 col-form-label">
				                     	<label for="alt_contact_number" class="bmd-label-floating"> Alternate Contact Number*</label>
				                     </div>
				                    <div class="col-sm-10">
				                        <div class="form-group bmd-form-group">
				                            <input disabled type="text" name="alt_contact_number" id="alt_contact_number" class="form-control" autocomplete="off"  value="<?php echo e($leads->alt_contact_number); ?>" required maxlength="12">
				                            <?php if($errors->has('alt_contact_number')): ?>
																			<span class="error" role="alt_contact_number">
																				<strong><?php echo e($errors->first('alt_contact_number')); ?></strong>
																			</span>
																		<?php endif; ?>
				                        </div>
				                    </div>
				                </div>

												<div class="row">
				                	<div class="col-sm-2 col-form-label">
				                     	<label for="information" class="bmd-label-floating">Problem write your problem here*</label>
				                     </div>
				                    <div class="col-sm-10">
				                        <div class="form-group bmd-form-group">
				                            <textarea disabled name="information" id="information" cols="30" rows="10" class="form-control" autocomplete="off"  value="<?php echo e($leads->information); ?>" required><?php echo e($leads->information); ?></textarea>
				                            <?php if($errors->has('information')): ?>
																			<span class="error" role="information">
																				<strong><?php echo e($errors->first('information')); ?></strong>
																			</span>
																		<?php endif; ?>
				                        </div>
				                    </div>
				                </div>

				                <div class="row">
				                    <div class="col-sm-2 col-form-label">
															<div class="card-footer ">
																<input type="hidden" name="id" value="<?php echo e($leads->id); ?>">
						                  	<button type="submit" class="btn btn-fill btn-success">Assign<div class="ripple-container"></div></button>
						                	</div>
				                    </div>
				                </div>

										<?php echo e(Form::close()); ?>

				            <!-- </form> -->
				        </div>
				    </div>
					<!-- /card -->

				</div>
			</div>
			<!-- /row -->
		</div>
		<!-- /container-fluid -->
	</div>
	<!-- /content -->
</div>
<!-- content -->

<?php $__env->stopSection(); ?>


<?php $__env->startSection('admin::custom_js'); ?>

<script type="text/javascript">
$(document).ready(function () {

	$('#editLead').validate({
		rules: {		
			alt_contact_number: {
				required: true,
				minlength:9,
				maxlength:12,
				number: true
			},
			farm_id:"required",
			user_id:"required",
			service_id:"required",
			information:"required",
			consultant_id:"required",
		},
		messages: {
			alt_contact_number: {
				required: "please enter alternate phone number",
				minlength: "min length must be greater then 9 digit",
				maxlength:"max length must be less then 12 digit",
				number: "must be a number"
			},
			farm_id:"please select a farm",
			user_id:"please select a user",
			service_id:"please select a service",
			information:"please your message/information or problem",
			consultant_id:"please select a consultant to assign",
		}
	});

});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin::layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>