<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="content-type" content="text/html;charset=utf-8" />
        <?php echo $__env->make('admin::pages.head', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- Styles -->
        <?php echo $__env->make('admin::pages.style', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->yieldContent('admin::custom_css'); ?>
        <!-- End Styles -->
    </head>
    <body>
        <?php echo $__env->make('admin::pages.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('admin::pages.side_bar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->yieldContent('admin::content'); ?>
        <?php echo $__env->make('admin::pages.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- JavaScript -->
        <?php echo $__env->make('admin::pages.script', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->yieldContent('admin::script'); ?>
        <?php echo $__env->yieldContent('admin::custom_js'); ?>
        <!-- <?php echo $__env->make('toast', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?> -->
        <?php echo $__env->make('success-error-message', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo Toastr::message(); ?>


        <!-- End Javascript -->
    </body>
</html>
