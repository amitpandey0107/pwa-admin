<?php $__env->startSection('admin::title', 'consultant'); ?>

<?php $__env->startSection('admin::pagetitle', 'Add consultant'); ?>

<?php $__env->startSection('admin::content'); ?>

<style>
    .statchk .form-check-label {margin-top: 14px;}
    .imgmt{margin-top: 20px;}
</style>

<div class="content">
    <div class="container-fluid">
                <div class="row">
                    <div class="col-sm-12">
                        <?php if(count($errors) > 0): ?>
                        <div class = "alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <?php endif; ?>
        
                        <?php if(!empty($successMsg)): ?>
                        <div class="alert alert-success"> <?php echo e($successMsg); ?></div>
                        <?php endif; ?>
                    </div>
                </div>

        <div class="row">
            <div class="col-sm-12">
                <?php if(session()->has('success')): ?>
                <?php $__env->startSection('admin::custom_js'); ?>
                <script>
                    Swal.fire({
                        position: 'center',
                        type: 'success',
                        title: " <?php echo e(session()->get('success')); ?> ",
                        showConfirmButton: false,
                        timer: 3000
                    })
                </script>
                <?php $__env->stopSection(); ?>

                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-12 text-right">
                    <a href="<?php echo e(route('consultants')); ?>" class="btn btn-primary">
                        Back
                    </a>
                </div>
                <div class="col-md-12">

                    <div class="card ">
                        <div class="card-header card-header-rose card-header-text">
                            <div class="card-text">
                                <h4 class="card-title">Registration Form</h4>
                            </div>
                        </div>
                        <div class="card-body">				           

                            <form method="POST" class="form-horizontal" id="consultantForm" enctype="multipart/form-data" action="<?php echo e(route('consultant-add')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-sm-2 col-form-label">
                                        <label for="name" class="bmd-label-floating">Name *</label>
                                    </div>	
                                    <div class="col-sm-10">
                                        <div class="form-group bmd-form-group">
                                            <input type="text" name="name" id="firstname" maxlength="20" class="form-control required" autocomplete="off"  value="<?php echo e(old('name')); ?>">
                                            <?php if($errors->has('name')): ?>
                                            <span class="error" role="name">
                                                <strong><?php echo e($errors->first('name')); ?></strong>
                                            </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <label class="col-sm-2 col-form-label">Email *</label>
                                    <div class="col-sm-10">
                                        <div class="form-group bmd-form-group">
                                            <input type="text" name="email" id="email" maxlength="30" class="form-control required email" autocomplete="off" value="<?php echo e(old('email')); ?>">
                                            <?php if($errors->has('email')): ?>
                                            <span class="error" role="email">
                                                <strong><?php echo e($errors->first('email')); ?></strong>
                                            </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <label class="col-sm-2 col-form-label">Phone Number *</label>
                                    <div class="col-sm-10">
                                        <div class="form-group bmd-form-group">
                                            <input type="text" name="mobile_number" id="phone" maxlength="15" class="form-control required number" autocomplete="off" value="<?php echo e(old('mobile_number')); ?>">
                                            <?php if($errors->has('mobile_number')): ?>
                                            <span class="error" role="mobile_number">
                                                <strong><?php echo e($errors->first('mobile_number')); ?></strong>
                                            </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <label class="col-sm-2 col-form-label">Date of Birth *</label>
                                    <div class="col-sm-10">
                                        <div class="form-group bmd-form-group is-filled">
                                            <input type="text" class="form-control datepicker required" maxlength="20" autocomplete="off" name="date_of_birth" id="date_of_birth" value="<?php echo e(old('date_of_birth')); ?>">
                                            <?php if($errors->has('date_of_birth')): ?>
                                            <span class="error" role="date_of_birth">
                                                <strong><?php echo e($errors->first('date_of_birth')); ?></strong>
                                            </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <label class="col-sm-2 col-form-label label-checkbox">Gender</label>
                                    <div class="col-sm-10 checkbox-radios">
                                        <div class="form-check form-check-inline">
                                            <label class="form-check-label">
                                                <input class="form-check-input" type="radio" value="Male" name="gender" id="gendermale" checked="checked"> Male
                                                <span class="form-check-sign">
                                                    <span class="check"></span>
                                                </span>
                                            </label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <label class="form-check-label">
                                                <input class="form-check-input" type="radio" value="Female" name="gender" id="genderfemale"> Female
                                                <span class="form-check-sign">
                                                    <span class="check"></span>
                                                </span>
                                            </label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <label class="form-check-label">
                                                <input class="form-check-input" type="radio" value="Other" name="gender" id="genderother"> Other
                                                <span class="form-check-sign">
                                                    <span class="check"></span>
                                                </span>
                                            </label>
                                        </div>
                                    </div>
                                </div>

                                <!--                            <div class="row">
                                                                <label class="col-sm-2 col-form-label">Status</label>
                                                                <div class="col-sm-10">
                                                                    <div class="form-check statchk">
                                                                        <label class="form-check-label">
                                                                            <input class="form-check-input" type="checkbox" name="status" id="status" checked=""> Status
                                                                            <span class="form-check-sign">
                                                                                <span class="check"></span>
                                                                            </span>
                                                                        </label>
                                                                    </div>
                                                                </div>
                                                            </div>-->

<!--                                <input type="hidden" class="form-control" autocomplete="off" name="role_id" id="role_id" value="3">-->
                                <div class="row">
                                    <div class="col-sm-2 col-form-label">
                                        <div class="card-footer ">
                                            <button type="submit" class="btn btn-fill btn-rose">Submit<div class="ripple-container"></div></button>
                                        </div>
                                    </div>				                   
                                </div>
                            </form>
                        </div>
                    </div>
                    <!-- /card -->

                </div>
            </div>
            <!-- /row -->
        </div>
        <!-- /container-fluid -->
    </div>
    <!-- /content -->
</div>
<!-- content -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('admin::custom_js'); ?>
<script type="text/javascript">
    $(document).ready(function () {
        $('#consultantForm').validate();

        $(".datepicker").datepicker({
            dateFormat: "yy-mm-dd",
            maxDate: new Date()
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin::layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>