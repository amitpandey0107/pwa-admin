<html>
    <head>
        <title>Register Consultant</title>
    </head>
    <body>
        Name: <?php echo e($name); ?><br>
        Email: <?php echo e($email); ?><br>
        Password: <?php echo e($password); ?><br>
    </body>
</html>