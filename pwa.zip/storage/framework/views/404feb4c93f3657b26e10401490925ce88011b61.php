<?php $__env->startSection('admin::title', 'Consultants'); ?>

<?php $__env->startSection('admin::pagetitle', 'Service Details'); ?>

<?php $__env->startSection('admin::content'); ?>

<style>
    .statchk .form-check-label {margin-top: 14px;}
    .imgmt{margin-top: 20px;}
</style>

<div class="content">

    <div class="content">
        <div class="container-fluid">

            <div class="row">
                <div class="col-sm-12">
                    <?php if(count($errors) > 0): ?>
                    <div class = "alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <?php endif; ?>

                    <?php if(!empty($successMsg)): ?>
                    <div class="alert alert-success"> <?php echo e($successMsg); ?></div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="row">                
                <div class="col-md-12">

                    <div class="card ">
                        <div class="card-header card-header-success card-header-icon">
                            <div class="card-icon">
                                <i class="material-icons">assignment</i>
                            </div>
                            <h4 class="card-title">Service Details
                                <a href="<?php echo e(route('consultants')); ?>">
                                    <button class="btn btn-success" style="float:right">Back</button>
                                </a>
                            </h4>
                        </div>
                        <div class="card-body ">
                           

                            <div class="row">
                                <div class="col-sm-2 col-form-label">
                                    <label class="bmd-label-floating">Service ID</label>
                                </div>  
                                <div class="col-sm-10">
                                    <div class="form-group bmd-form-group">
                                        <span class="bmd-label-floating"><?php echo e((int)1000000000+$leads->id); ?></span>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-sm-2 col-form-label">
                                    <label class="bmd-label-floating">Farmer Name</label>
                                </div>  
                                <div class="col-sm-10">
                                    <div class="form-group bmd-form-group">
                                        <span class="bmd-label-floating"><?php echo e($leads->getUserName->name); ?></span>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-sm-2 col-form-label">
                                    <label class="bmd-label-floating">Farm Name</label>
                                </div>  
                                <div class="col-sm-10">
                                    <div class="form-group bmd-form-group">
                                        <span class="bmd-label-floating"><?php echo e($leads->getFarmName->farm_name); ?></span>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-sm-2 col-form-label">
                                    <label class="bmd-label-floating">Close Comment</label>
                                </div>  
                                <div class="col-sm-10">
                                    <div class="form-group bmd-form-group">
                                        <span class="bmd-label-floating"><?php echo e(isset($leads->close_comment) ? $leads->close_comment : 'NA'); ?></span>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-sm-2 col-form-label">
                                    <label class="bmd-label-floating">Date & Time</label>
                                </div>  
                                <div class="col-sm-10">
                                    <div class="form-group bmd-form-group">
                                        <span class="bmd-label-floating">
                                            <?php $date = explode(' ',$leads->created_at); 
                                            echo date("d-m-Y", strtotime($date[0])) . ' & ' . date("H:i:s", strtotime($date[1])) 
                                            ?>
                                        </span>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-sm-2 col-form-label">
                                    <label class="bmd-label-floating">Status</label>
                                </div>  
                                <div class="col-sm-10">
                                    <div class="form-group bmd-form-group">
                                        <span class="bmd-label-floating">
                                            <?php if($leads->status==0): ?>
                                            <span>Pending</span>
                                            <?php elseif($leads->status==1): ?>
                                            <span>In Process</span>
                                            <?php elseif($leads->status==2): ?>
                                            <span>Assigned</span>
                                            <?php elseif($leads->status==3): ?>
                                            <span>Hold</span>
                                            <?php elseif($leads->status==4): ?>
                                            <span>Completed</span>
                                            <?php elseif($leads->status==5): ?>
                                            <span>Cancel</span>
                                            <?php else: ?>
                                            <span>NA</span>
                                            <?php endif; ?>
                                        </span>
                                    </div>
                                </div>
                            </div>



                        </div>
                    </div>
                    <!-- /card -->

                </div>
            </div>
            <!-- /row -->
        </div>
        <!-- /container-fluid -->
    </div>
    <!-- /content -->
</div>
<!-- content -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('admin::custom_js'); ?>
<script type="text/javascript">
    $(document).ready(function () {
        $('#consultantForm').validate();
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin::layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>