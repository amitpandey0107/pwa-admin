<?php $__env->startSection('admin::title', 'Services'); ?>

<?php $__env->startSection('admin::pagetitle', 'Edit Services'); ?>

<?php $__env->startSection('admin::content'); ?>

<style>
.statchk .form-check-label {margin-top: 14px;}
.imgmt{margin-top: 20px;}
.form-group input[type=file] {opacity: 1; position: relative; z-index: 0; }
select#product_subcateory {border: none; border-bottom: 1px solid #ccc; width: 27%; color: #999; position:relative;}
</style>

<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-12">
				<?php if(count($errors) > 0): ?>
			       <div class = "alert alert-danger">
			          <ul>
			             <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			                <li><?php echo e($error); ?></li>
			             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			          </ul>
			       </div>
			    <?php endif; ?>

			    <?php if(!empty($successMsg)): ?>
			      <div class="alert alert-success"> <?php echo e($successMsg); ?></div>
			    <?php endif; ?>
			</div>
		</div>

		<div class="row">
			<div class="col-sm-12">
				<?php if(session()->has('success')): ?>
					<?php $__env->startSection('admin::custom_js'); ?>
					<script>
						Swal.fire({
						  position: 'center',
						  type: 'success',
						  title: " <?php echo e(session()->get('success')); ?> ",
						  showConfirmButton: false,
						  timer: 4000
						})
					</script>
					<?php $__env->stopSection(); ?>
				<?php endif; ?>

        <?php if(session()->has('error')): ?>
					<?php $__env->startSection('admin::custom_js'); ?>
					<script>
						Swal.fire({
							position: 'center',
							type: 'error',
							title: " <?php echo e(session()->get('error')); ?> ",
							showConfirmButton: false,
							timer: 4000
						})
					</script>
					<?php $__env->stopSection(); ?>
				<?php endif; ?>

			</div>
		</div>
	</div>

	<div class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">

				    <div class="card ">
						<div class="card-header card-header-success card-header-icon">
										<div class="card-icon">
												<i class="material-icons">assignment</i>
										</div>
										<h4 class="card-title">Edit Service Form
												<a href="<?php echo e(route('services')); ?>">
														<button class="btn btn-success" style="float:right">Back</button>
												</a>
										</h4>
								</div>
				        <div class="card-body">
				            	<?php echo e(Form::open(array('url' => url('admin/edit-service'), 'method'=>'post', 'class'=>'form-horizontal', 'id'=>'editservices', 'enctype'=>'multipart/form-data'))); ?>

											<?php echo csrf_field(); ?>



				                <div class="row">
				                	<div class="col-sm-2 col-form-label">
				                     	<label for="service_name" class="bmd-label-floating"> Name *</label>
				                     </div>
				                    <div class="col-sm-10">
				                        <div class="form-group bmd-form-group">
				                            <input type="text" name="service_name" id="service_name" class="form-control" autocomplete="off"  value="<?php echo e($service->service_name); ?>">
				                            <?php if($errors->has('service_name')): ?>
																			<span class="error" role="service_name">
																				<strong><?php echo e($errors->first('service_name')); ?></strong>
																			</span>
																		<?php endif; ?>
				                        </div>
				                    </div>
				                </div>

				                <div class="row">
				                	<div class="col-sm-2 col-form-label">
				                     	<label for="service_details" class="bmd-label-floating"> Service Details *</label>
				                     </div>
				                    <div class="col-sm-10">
				                        <div class="form-group bmd-form-group">
				                            <textarea name="service_details" id="service_details" cols="30" rows="10" value="<?php echo e($service->service_details); ?>" class="form-control"><?php echo e($service->service_details); ?></textarea>
				                            <?php if($errors->has('service_details')): ?>
																				<span class="error" role="service_details">
																						<strong><?php echo e($errors->first('service_details')); ?></strong>
																				</span>
																		<?php endif; ?>
				                        </div>
				                    </div>
				                </div>

				                <div class="row">
				                    <div class="col-sm-2 col-form-label">
															<div class="card-footer ">
                              <input type="hidden" name="id" value="<?php echo e($service->id); ?>">
						                  	<button type="submit" class="btn btn-fill btn-success">Submit<div class="ripple-container"></div></button>
						                	</div>
				                    </div>
				                </div>

										<?php echo e(Form::close()); ?>

				            <!-- </form> -->
				        </div>
				    </div>
					<!-- /card -->

				</div>
			</div>
			<!-- /row -->
		</div>
		<!-- /container-fluid -->
	</div>
	<!-- /content -->
</div>
<!-- content -->

<?php $__env->stopSection(); ?>


<?php $__env->startSection('admin::custom_js'); ?>

<script type="text/javascript">
$(document).ready(function () {
	$('#editservices').validate({
			rules:{
				service_name:"required",
			}, 
			messages:{
				service_name:"Please enter service name",
			}
	});
});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin::layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>