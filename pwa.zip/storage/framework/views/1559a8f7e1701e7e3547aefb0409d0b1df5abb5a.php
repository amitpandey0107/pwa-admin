<?php $__env->startSection('admin::content'); ?>
<div class="content">
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card ">
                        <div class="card-header card-header-success card-header-icon">
                            <div class="card-icon">
                                <i class="material-icons">dashboard</i>
                            </div>
                            <h4 class="card-title">Dashboard</h4>
                        </div>
                        <div class="card-body ">
                            <div class="row">
                                <div class="col-lg-3 col-md-6 col-sm-6">
                                    <div class="card card-stats">
                                        <div class="card-header card-header-warning card-header-icon">
                                            <div class="card-icon">
                                                <i class="material-icons">account_circle</i>
                                            </div>
                                            <p class="card-category">Users</p>
                                            <h3 class="card-title">
                                            </h3>
                                        </div>
                                        <div class="card-footer">
                                            <div class="stats">
                                                <a class="card-category" href="">
                                                    <i class="material-icons">visibility</i>
                                                    View All Users
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin::layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>