<?php $__env->startSection('admin::content'); ?>
<!-- End Navbar -->
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header card-header-success card-header-icon">
                        <div class="card-icon">
                            <i class="material-icons">perm_identity</i>
                        </div>
                        <h4 class="card-title">Edit Profile</h4>
                    </div>
                    <div class="card-body">

                        <form method="POST" action="<?php echo e(route('admin-edit-profile')); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="bmd-label-floating">Name</label>
                                        <input type="text" name="name" value="<?php echo e(Auth::user()->name); ?>" class="form-control">
                                        <?php if($errors->has('name')): ?>
                                        <span class="error" role="alert">
                                            <strong><?php echo e($errors->first('name')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="bmd-label-floating">Email</label>
                                        <input type="email" name="email" value="<?php echo e(Auth::user()->email); ?>" class="form-control">
                                        <?php if($errors->has('email')): ?>
                                        <span class="error" role="alert">
                                            <strong><?php echo e($errors->first('email')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="bmd-label-floating">Mobile Number Country</label>
                                        <input type="number" name="mobile_code" value="<?php echo e(Auth::user()->mobile_code); ?>" class="form-control">
                                        <?php if($errors->has('mobile_code')): ?>
                                        <span class="error" role="alert">
                                            <strong><?php echo e($errors->first('mobile_code')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="bmd-label-floating">Mobile Number</label>
                                        <input type="number" name="mobile_number" value="<?php echo e(Auth::user()->mobile_number); ?>" class="form-control">
                                        <?php if($errors->has('mobile_number')): ?>
                                        <span class="error" role="alert">
                                            <strong><?php echo e($errors->first('mobile_number')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <button type="submit" class="btn btn-rose pull-right">Update Profile</button>
                            <div class="clearfix"></div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('admin::custom_js'); ?>
<script>
    $(document).ready(function () {
        var readURL = function (input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function (e) {
                    $('#PicturePreview').attr('src', e.target.result);
                }
                reader.readAsDataURL(input.files[0]);
            }
        }


        $("#picture").on('change', function () {
            readURL(this);
        });

        $("#PicturePreview").on('click', function () {
            $('#picture').click();
        });
    });
</script>
<?php $__env->stopSection(); ?>   


<?php echo $__env->make('admin::layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>