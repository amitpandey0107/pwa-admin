<?php $__env->startSection('admin::title', 'Extension Manager'); ?>

<?php $__env->startSection('admin::pagetitle', 'Job Assigned'); ?>

<?php $__env->startSection('admin::content'); ?>

<style>
    .statchk .form-check-label {margin-top: 14px;}
    .imgmt{margin-top: 20px;}
</style>

<div class="content">

    <div class="content">
        <div class="container-fluid">

            <div class="row">
                <div class="col-sm-12">
                    <?php if(count($errors) > 0): ?>
                    <div class = "alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <?php endif; ?>

                    <?php if(!empty($successMsg)): ?>
                    <div class="alert alert-success"> <?php echo e($successMsg); ?></div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="row">                
                <div class="col-md-12">

                    <div class="card ">
                        <div class="card-header card-header-success card-header-icon">
                            <div class="card-icon">
                                <i class="material-icons">assignment</i>
                            </div>
                            <h4 class="card-title">Services Assigned
                               <span style="padding-left: 20px; text-decoration: underline;">Total Services: <strong><?php echo e(count($leads)); ?></strong></span>
                                <a href="<?php echo e(route('extension-manager')); ?>">
                                    <button class="btn btn-success" style="float:right">Back</button>
                                </a>
                            </h4>
                        </div>
                        <div class="card-body ">
                             <div class="toolbar"></div>
                             <div class="material-datatables">
                                <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
                                    <thead>
                                        <tr>
                                            <th>Request ID</th>
                                            <th>Date</th>
                                            <th>Farmer</th>
                                            <th>Farm Name</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tfoot> 
                                        <tr>
                                            <th>Request ID</th>
                                            <th>Date</th>
                                            <th>Farmer</th>
                                            <th>Farm Name</th>   
                                            <th>Status</th>
                                        </tr>
                                    </tfoot>
                                    <tbody>
                                        <?php if(count($leads) > 0 ): ?>
                                            <?php $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                        
                                            <tr>
                                                <td>
                                                    <a href="javascript:;">
                                                    <?php echo e((int)1000000000+$data->id); ?>

                                                    </a>
                                                </td>
                                                <td><?php $date = explode(' ',$data->created_at); echo date("d-m-Y", strtotime($date[0])) ?></td>
                                                <td><?php echo e($data->getUserName->name); ?></td>
                                                <td><?php echo e($data->getFarmName->farm_name); ?></td> 
                                                <td> 
                                                    <select name="status" id="statusid_<?php echo e($data->id); ?>" class="form-control" onchange="updateStatus('<?php echo e(route('lead-status', $data->id)); ?>', <?php echo e($data->id); ?>)">
                                                    <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($data->status == $key): ?>
                                                        <option value="<?php echo e($key); ?>" selected><?php echo e($value); ?></option>
                                                        <?php else: ?>
                                                        <option value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>                                        
                                                </td>            
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                        <tr><td colspan="7">No Record Found</td></tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                             </div>
                        </div>
                    </div>
                    <!-- /card -->

                </div>
            </div>
            <!-- /row -->
        </div>
        <!-- /container-fluid -->
    </div>
    <!-- /content -->
</div>
<!-- content -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('admin::custom_js'); ?>
<script type="text/javascript">   

    function closeRequest(param) {
    Swal.fire({
    title: 'Are you sure?',
            text: "You won't be able to perform this action.",
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, Update it!'
    }).then((result) => {
    if (result.value) {
    Swal.fire(
            'Updated!',
            'User status updated.',
            'success'
            )
            window.location = param
    }
    })
    }


    function updateStatus(param, id) { 
        var e = document.getElementById("statusid_"+id);
        var strUser = e.options[e.selectedIndex].value;
        
        Swal.fire({
        title: 'Are you sure?',
            text: "You won't be able to perform this action.",
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, Update it!'
        }).then((result) => {
            if (result.value) {
                Swal.fire(
                'Updated!',
                'Status Updated Successfully.',
                'success'
                )
                window.location = param+'_'+strUser
            }
        })
    }


    
    $('#datatables').DataTable({
        "pagingType": "full_numbers",
        "lengthMenu": [
        [10, 25, 50, -1],
                [10, 25, 50, "All"]
        ],
        responsive: true,
        language: {
        search: "_INPUT_",
                searchPlaceholder: "Search records",
        }
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin::layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>