<?php $__env->startSection('admin::title', 'Questions & Answers'); ?>

<?php $__env->startSection('admin::pagetitle', 'Add Questions'); ?>

<?php $__env->startSection('admin::content'); ?>

<style>
.statchk .form-check-label {margin-top: 14px;}
.imgmt{margin-top: 20px;}
.form-group input[type=file] {opacity: 1; position: relative; z-index: 0; }
select#product_subcateory {border: none; border-bottom: 1px solid #ccc; width: 27%; color: #999; position:relative;}
</style>

<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-12">
				<?php if(count($errors) > 0): ?>
			       <div class = "alert alert-danger">
			          <ul>
			             <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			                <li><?php echo e($error); ?></li>
			             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			          </ul>
			       </div>
			    <?php endif; ?>

			    <?php if(!empty($successMsg)): ?>
			      <div class="alert alert-success"> <?php echo e($successMsg); ?></div>
			    <?php endif; ?>
			</div>
		</div>

		<div class="row">
			<div class="col-sm-12">
				<?php if(session()->has('success')): ?>

					<?php $__env->startSection('admin::custom_js'); ?>
					<script>
						Swal.fire({
						  position: 'center',
						  type: 'success',
						  title: " <?php echo e(session()->get('success')); ?> ",
						  showConfirmButton: false,
						  timer: 3000
						})
					</script>
					<?php $__env->stopSection(); ?>

				<?php endif; ?>
			</div>
		</div>
	</div>

	<div class="content">
		<div class="container-fluid">
			<div class="row">				
				<div class="col-md-12">

				    <div class="card ">
							<div class="card-header card-header-success card-header-icon">
								<div class="card-icon">
									<i class="material-icons">assignment</i>
								</div>
								<h4 class="card-title">Add Question Form
									<a href="<?php echo e(route('questions')); ?>">
										<button class="btn btn-success" style="float:right">Back</button>
									</a>
								</h4>
							</div>
				       		<div class="card-body">
				            	<?php echo e(Form::open(array('url' => url('admin/questions-add'), 'method'=>'post', 'class'=>'form-horizontal', 'id'=>'questionsadd', 'enctype'=>'multipart/form-data'))); ?>

								<?php echo csrf_field(); ?>

				                <div class="row">
				                	<div class="col-sm-2 col-form-label">
				                     	<label for="question" class="bmd-label-floating">Your Question *</label>
				                     </div>
				                    <div class="col-sm-10">
				                        <div class="form-group bmd-form-group">
				                            <input type="text" name="question" id="question" class="form-control" autocomplete="off"  value="<?php echo e(old('question')); ?>">
				                            <?php if($errors->has('question')): ?>
												<span class="error" role="question">
													<strong><?php echo e($errors->first('question')); ?></strong>
												</span>
											<?php endif; ?>
				                        </div>
				                    </div>
				                </div>
								

								<div class="row">
				                	<div class="col-sm-2 col-form-label">
				                     	<label for="option1" class="bmd-label-floating"> Option 1 *</label>
				                     </div>
				                    <div class="col-sm-10">
				                        <div class="form-group bmd-form-group">
				                            <input type="text" name="option1" id="option1" class="form-control" autocomplete="off"  value="<?php echo e(old('option1')); ?>">
				                            <?php if($errors->has('option1')): ?>
												<span class="error" role="option1">
													<strong><?php echo e($errors->first('option1')); ?></strong>
												</span>
											<?php endif; ?>
				                        </div>
				                    </div>
				                </div>

								<div class="row">
				                	<div class="col-sm-2 col-form-label">
				                     	<label for="option2" class="bmd-label-floating"> Option 2 *</label>
				                     </div>
				                    <div class="col-sm-10">
				                        <div class="form-group bmd-form-group">
				                            <input type="text" name="option2" id="option2" class="form-control" autocomplete="off"  value="<?php echo e(old('option2')); ?>">
				                            <?php if($errors->has('option2')): ?>
												<span class="error" role="option2">
													<strong><?php echo e($errors->first('option2')); ?></strong>
												</span>
											<?php endif; ?>
				                        </div>
				                    </div>
				                </div>

								<div class="row">
				                	<div class="col-sm-2 col-form-label">
				                     	<label for="option3" class="bmd-label-floating"> Option 3 *</label>
				                     </div>
				                    <div class="col-sm-10">
				                        <div class="form-group bmd-form-group">
				                            <input type="text" name="option3" id="option3" class="form-control" autocomplete="off"  value="<?php echo e(old('option3')); ?>">
				                            <?php if($errors->has('option3')): ?>
												<span class="error" role="option3">
													<strong><?php echo e($errors->first('option3')); ?></strong>
												</span>
											<?php endif; ?>
				                        </div>
				                    </div>
				                </div>

								<div class="row">
				                	<div class="col-sm-2 col-form-label">
				                     	<label for="option4" class="bmd-label-floating"> Option 4 *</label>
				                     </div>
				                    <div class="col-sm-10">
				                        <div class="form-group bmd-form-group">
				                            <input type="text" name="option4" id="option4" class="form-control" autocomplete="off"  value="<?php echo e(old('option4')); ?>">
				                            <?php if($errors->has('option4')): ?>
												<span class="error" role="option4">
													<strong><?php echo e($errors->first('option4')); ?></strong>
												</span>
											<?php endif; ?>
				                        </div>
				                    </div>
				                </div>


								<div class="row">
				                	<div class="col-sm-2 col-form-label">
				                     	<label for="correct_answer" class="bmd-label-floating">Select Correct Answer</label>
				                     </div>
				                    <div class="col-sm-10">
				                        <div class="form-group bmd-form-group">
											<select class="selectpicker" data-style="select-with-transition" data-size="7" autocomplete="off" name="correct_answer" id="correct_answer">
					                            <option value="">Choose Correct Answer</option>
												<option value="1">1</option>
												<option value="2">2</option>
												<option value="3">3</option>
												<option value="4">4</option>
				                         	</select>
				                            <?php if($errors->has('correct_answer')): ?>
												<span class="error" role="correct_answer">
													<strong><?php echo e($errors->first('correct_answer')); ?></strong>
												</span>
											<?php endif; ?>
				                        </div>
				                    </div>
				                </div>
												
										                

				                <div class="row">
				                    <div class="col-sm-2 col-form-label">
										<div class="card-footer ">
						                  	<button type="submit" class="btn btn-fill btn-success">Submit<div class="ripple-container"></div></button>
						                </div>
				                    </div>
				                </div>
								<?php echo e(Form::close()); ?>

				            <!-- </form> -->
				        </div>
				    </div>
					<!-- /card -->

				</div>
			</div>
			<!-- /row -->
		</div>
		<!-- /container-fluid -->
	</div>
	<!-- /content -->
</div>
<!-- content -->

<?php $__env->stopSection(); ?>


<?php $__env->startSection('admin::custom_js'); ?>

<script type="text/javascript">
$(document).ready(function () {
		$('#questionsadd').validate({
			rules:{
				question:"required",
				option1:"required",
				option2:"required",
				option3:"required",
				option4:"required",
				correct_answer:"required",
			}, 
			messages:{
				question:"Please enter your question",
				option1:"Please enter option first",
				option2:"Please enter option second",
				option3:"Please enter option third",
				option4:"Please enter option forth",
				correct_answer:"Please select correct option",
			}
	});
});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin::layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>