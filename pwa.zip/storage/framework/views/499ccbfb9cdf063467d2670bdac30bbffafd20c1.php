<?php $urlName = Request::segment(2); ?>
<div class="sidebar" data-color="rose" data-background-color="black" data-image="<?php echo e(asset('img/sidebar-1.jpg')); ?>">
    <div class="logo">
        <a href="javacript:void(0)" class="simple-text logo-mini">
            <img src="<?php echo e(asset('img/logo-1.png')); ?>"/>
        </a>
        <a href="<?php echo e(route('dashboard')); ?>" class="simple-text logo-normal">
            Farmer
        </a>
    </div>
    <div class="sidebar-wrapper">
        <ul class="nav">
            <li class="nav-item <?php if($urlName == '/' || $urlName == 'dashboard'){ echo "active"; }       ?>">
                <a class="nav-link" href="<?php echo e(route('dashboard')); ?>">
                    <i class="material-icons">dashboard</i>
                    <p> Dashboard </p>
                </a>
            </li>          
            <li class="nav-item <?php if($urlName == 'consultant-add' || $urlName == 'consultants' || $urlName == 'consultant-edit' || $urlName == 'consultant-view' || $urlName == 'consultant-services'){ echo "active"; }       ?>">
                <a class="nav-link" href="<?php echo e(route('consultants')); ?>">
                    <i class="material-icons">people_alt</i>
                    <p> Manage Consultants </p>
                </a>
            </li>

            <li class="nav-item <?php if($urlName == 'add-service' || $urlName == 'services' || $urlName=='edit-service' || $urlName == 'service-view'){ echo "active"; }       ?>">
                <a class="nav-link" href="<?php echo e(route('services')); ?>">
                    <i class="material-icons">build</i>
                    <p> Manage Services </p>
                </a>
            </li> 

           

            <li class="nav-item <?php if($urlName == 'categories' || $urlName == 'category-add' || $urlName == 'category-edit' || $urlName == 'category-view'){ echo "active"; }       ?>">
            <a class="nav-link collapsed" data-toggle="collapse" href="#formsExamples" aria-expanded="false">
              <i class="material-icons">category</i>
              <p> Manage Categories
                <b class="caret"></b>
              </p>
            </a>
            <div class="collapse" id="formsExamples" style="">
              <ul class="nav">
                <li class="nav-item ">
                  <a class="nav-link" href="<?php echo e(route('categories')); ?>">
                    <span class="sidebar-mini"> C </span>
                    <span class="sidebar-normal"> Category </span>
                  </a>
                </li>
                <li class="nav-item ">
                  <a class="nav-link" href="<?php echo e(route('subcategories')); ?>">
                    <span class="sidebar-mini"> C </span>
                    <span class="sidebar-normal"> Child Category </span>
                  </a>
                </li>
                
              </ul>
            </div>
          </li>


           <li class="nav-item <?php if($urlName == 'farmers' || $urlName == 'farmer-add' || $urlName == 'farmer-edit' || $urlName == 'farmer-view'){ echo "active"; }       ?>">
                <a class="nav-link" href="<?php echo e(route('farmers')); ?>">
                    <i class="material-icons">people_alt</i>
                    <p> Manage Farmers </p>
                </a>
            </li>

            <li class="nav-item <?php if($urlName == 'farms' || $urlName == 'farm-add' || $urlName == 'farm-edit' || $urlName == 'farm-view'){ echo "active"; }       ?>">
                <a class="nav-link" href="<?php echo e(route('farms')); ?>">
                    <i class="material-icons">local_florist</i>
                    <p> Manage Farm </p>
                </a>
            </li>

            <li class="nav-item <?php if($urlName == 'leads' || $urlName == 'lead-add' || $urlName == 'lead-edit' || $urlName == 'lead-view'){ echo "active"; }       ?>">
                <a class="nav-link" href="<?php echo e(route('leads')); ?>">
                    <i class="material-icons">dynamic_feed</i>
                    <p> Manage Service Requests </p>
                </a>
            </li>

            <li class="nav-item <?php echo ($urlName == 'cms-page-list' || $urlName == 'cms-page-view') ? "active" : ""; ?> ">
                <a class="nav-link" href="<?php echo e(route('cms-page-list')); ?>">
                    <i class="material-icons">menu_book</i>
                    <p> CMS Pages </p>
                </a>
            </li>

            <li class="nav-item <?php echo ($urlName == 'status' || $urlName == 'status-add' || $urlName == 'status-edit' || $urlName == 'status-view') ? "active" : ""; ?> ">
                <a class="nav-link" href="<?php echo e(route('status')); ?>">
                    <i class="material-icons">sync</i>
                    <p> Status Management </p>
                </a>
            </li>

            <li class="nav-item <?php echo ($urlName == 'extension-manager' || $urlName == 'extension-manager-add' || $urlName == 'extension-manager-edit' || $urlName == 'extension-manager-view') || $urlName == 'extension-services' ? "active" : ""; ?> ">
                <a class="nav-link" href="<?php echo e(route('extension-manager')); ?>">
                    <i class="material-icons">people_alt</i>
                    <p> Extension Manager </p>
                </a>
            </li>

           <li class="nav-item <?php if($urlName == '/' || $urlName == 'reports'){ echo "active"; } ?>">
                <a class="nav-link" href="<?php echo e(route('reports')); ?>">
                    <i class="material-icons">insert_chart_outlined</i>
                    <p> Manage Reports </p>
                </a>
            </li>

            <li class="nav-item <?php if($urlName == '/' || $urlName == 'surveys'){ echo "active"; }       ?>">
                <a class="nav-link" href="<?php echo e(route('surveys')); ?>">
                    <i class="material-icons">cast</i>
                    <p> Manage Surveys </p>
                </a>
            </li> 

            <li class="nav-item <?php if($urlName == '/' || $urlName == 'questions' || $urlName =='questions-add' || $urlName=='questions-edit'){ echo "active"; }       ?>">
                <a class="nav-link" href="<?php echo e(route('questions')); ?>">
                    <i class="material-icons">check_box</i>
                    <p> Questions & Answers </p>
                </a>
            </li> 

            <li class="nav-item <?php if($urlName == '/' || $urlName == 'faq' || $urlName =='faq-add' || $urlName=='faq-edit'){ echo "active"; }       ?>">
                <a class="nav-link" href="<?php echo e(route('faq')); ?>">
                    <i class="material-icons">check_box</i>
                    <p> FAQ </p>
                </a>
            </li> 


            <li class="nav-item <?php echo ($urlName == 'admin-logout') ? "active" : ""; ?> ">
                <a class="nav-link" href=""
                    onclick="event.preventDefault();
                            document.getElementById('logout-form').submit();">
                   <i class="material-icons">power_settings_new</i>
                    <p> Logout </p>
                </a>
                <form id="logout-form" action="<?php echo e(route('admin-logout')); ?>" method="POST" style="display: none;">
                    <?php echo csrf_field(); ?>
                </form>
            </li>

            <!--  <li class="nav-item <?php //if($urlName == '/' || $urlName == 'dashboard'){ echo "active"; }       ?>">
                <a class="nav-link" href="">
                    <i class="material-icons">dashboard</i>
                    <p> Manage Services </p>
                </a>
            </li>          
            <li class="nav-item <?php //if($urlName == '/' || $urlName == 'dashboard'){ echo "active"; }       ?>">
                <a class="nav-link" href="">
                    <i class="material-icons">dashboard</i>
                    <p> CMS Management </p>
                </a>
            </li>          
            <li class="nav-item <?php //if($urlName == '/' || $urlName == 'dashboard'){ echo "active"; }       ?>">
                <a class="nav-link" href="">
                    <i class="material-icons">dashboard</i>
                    <p> Email/Notification </p>
                </a>
            </li>          
            <li class="nav-item <?php //if($urlName == '/' || $urlName == 'dashboard'){ echo "active"; }       ?>">
                <a class="nav-link" href="">
                    <i class="material-icons">dashboard</i>
                    <p> Execute Campaigns </p>
                </a>
            </li>          
            <li class="nav-item <?php //if($urlName == '/' || $urlName == 'dashboard'){ echo "active"; }       ?>">
                <a class="nav-link" href="">
                    <i class="material-icons">dashboard</i>
                    <p> Surveys </p>
                </a>
            </li>          -->
        </ul>
    </div>
</div>
