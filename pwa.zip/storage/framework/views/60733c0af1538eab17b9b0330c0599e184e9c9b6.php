<?php $__env->startSection('admin::title', 'Status'); ?>

<?php $__env->startSection('admin::pagetitle', 'View Status'); ?>

<?php $__env->startSection('admin::content'); ?>

<style>
.statchk .form-check-label {margin-top: 14px;}
.imgmt{margin-top: 20px;}
.form-group input[type=file] {opacity: 1; position: relative; z-index: 0; }
select#product_subcateory {border: none; border-bottom: 1px solid #ccc; width: 27%; color: #999; position:relative;}
</style>

<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-12">
				<?php if(count($errors) > 0): ?>
			       <div class = "alert alert-danger">
			          <ul>
			             <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			                <li><?php echo e($error); ?></li>
			             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			          </ul>
			       </div>
			    <?php endif; ?>

			    <?php if(!empty($successMsg)): ?>
			      <div class="alert alert-success"> <?php echo e($successMsg); ?></div>
			    <?php endif; ?>
			</div>
		</div>

		<div class="row">
			<div class="col-sm-12">
				<?php if(session()->has('success')): ?>

					<?php $__env->startSection('admin::custom_js'); ?>
					<script>
						Swal.fire({
						  position: 'center',
						  type: 'success',
						  title: " <?php echo e(session()->get('success')); ?> ",
						  showConfirmButton: false,
						  timer: 3000
						})
					</script>
					<?php $__env->stopSection(); ?>

				<?php endif; ?>
			</div>
		</div>
	</div>

	<div class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-sm-12 text-right">
					<a href="<?php echo e(route('status')); ?>" class="btn btn-primary">
						 Back
					</a>
				</div>
				<div class="col-md-12">

				    <div class="card ">
				        <div class="card-header card-header-rose card-header-text">
				            <div class="card-text">
				                <h4 class="card-title">View Status</h4>
				            </div>
				        </div>
				        <div class="card-body">
				            	<?php echo e(Form::open(array('url' => url('admin/status-edit'), 'method'=>'post', 'class'=>'form-horizontal', 'id'=>'addStatus', 'enctype'=>'multipart/form-data'))); ?>

											<?php echo csrf_field(); ?>



                                <div class="row">
				                	<div class="col-sm-2 col-form-label">
				                     	<label for="status_type" class="bmd-label-floating"> Status Type *</label>
				                     </div>
				                    <div class="col-sm-10">
				                        <div class="form-group bmd-form-group">
                                        <select class="selectpicker" data-style="select-with-transition" data-size="7" autocomplete="off" name="status_type" id="status_type" disabled>
                                        <?php $__currentLoopData = $type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($key==$status->status_type): ?>
                                            <option value="<?php echo e($key); ?>" selected><?php echo e($value); ?></option>
                                            <?php else: ?>
                                            <option value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>															
                                        </select>
                                        <?php if($errors->has('status_type')): ?>
                                            <span class="error" role="status_type">
                                                <strong><?php echo e($errors->first('status_type')); ?></strong>
                                            </span>
                                        <?php endif; ?>
				                        </div>
				                    </div>
				                </div>


				                <div class="row">
				                	<div class="col-sm-2 col-form-label">
				                     	<label for="status_name" class="bmd-label-floating"> Name *</label>
				                     </div>
				                    <div class="col-sm-10">
				                        <div class="form-group bmd-form-group">
				                            <input type="text" name="status_name" id="status_name" class="form-control" autocomplete="off" disabled value="<?php echo e($status->status_name); ?>">
				                            <?php if($errors->has('status_name')): ?>
                                                <span class="error" role="status_name">
                                                    <strong><?php echo e($errors->first('status_name')); ?></strong>
                                                </span>
                                            <?php endif; ?>
				                        </div>
				                    </div>
				                </div>

                                <div class="row">
				                	<div class="col-sm-2 col-form-label">
				                     	<label for="status_description" class="bmd-label-floating"> Description *</label>
				                     </div>
				                    <div class="col-sm-10">
				                        <div class="form-group bmd-form-group">
                                            <textarea name="status_description" id="status_description" cols="30" rows="5" id="status_description" class="form-control" value="<?php echo e($status->status_description); ?>" disabled><?php echo e($status->status_description); ?></textarea>
                                            <?php if($errors->has('status_description')): ?>
                                                <span class="error" role="status_description">
                                                    <strong><?php echo e($errors->first('status_description')); ?></strong>
                                                </span>
                                            <?php endif; ?>
				                        </div>
				                    </div>
				                </div>				                

				                <div class="row">
				                    <div class="col-sm-2 col-form-label">
                                        <div class="card-footer ">
                                            <input type="hidden" id="id" name="id" value="<?php echo e($status->id); ?>">
                                        </div>						                  	
				                    </div>
				                </div>

										<?php echo e(Form::close()); ?>

				            <!-- </form> -->
				        </div>
				    </div>
					<!-- /card -->

				</div>
			</div>
			<!-- /row -->
		</div>
		<!-- /container-fluid -->
	</div>
	<!-- /content -->
</div>
<!-- content -->

<?php $__env->stopSection(); ?>


<?php $__env->startSection('admin::custom_js'); ?>

<script type="text/javascript">
$(document).ready(function () {
	$('#addStatus').validate();
});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin::layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>