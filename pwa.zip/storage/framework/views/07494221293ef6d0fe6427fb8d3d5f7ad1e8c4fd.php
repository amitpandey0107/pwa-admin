<?php $__env->startSection('admin::title', 'Farms'); ?>

<?php $__env->startSection('admin::pagetitle', 'Edit Farm'); ?>

<?php $__env->startSection('admin::content'); ?>

<style>
.statchk .form-check-label {margin-top: 14px;}
.imgmt{margin-top: 20px;}
.form-group input[type=file] {opacity: 1; position: relative; z-index: 0; }
select#product_subcateory {border: none; border-bottom: 1px solid #ccc; width: 27%; color: #999; position:relative;}
</style>

<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-12">
				<?php if(count($errors) > 0): ?>
			       <div class = "alert alert-danger">
			          <ul>
			             <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			                <li><?php echo e($error); ?></li>
			             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			          </ul>
			       </div>
			    <?php endif; ?>

			    <?php if(!empty($successMsg)): ?>
			      <div class="alert alert-success"> <?php echo e($successMsg); ?></div>
			    <?php endif; ?>
			</div>
		</div>

		<div class="row">
			<div class="col-sm-12">
				<?php if(session()->has('success')): ?>
					<?php $__env->startSection('admin::custom_js'); ?>
					<script>
						Swal.fire({
						  position: 'center',
						  type: 'success',
						  title: " <?php echo e(session()->get('success')); ?> ",
						  showConfirmButton: false,
						  timer: 3000
						})
					</script>
					<?php $__env->stopSection(); ?>
				<?php endif; ?>

				<?php if(session()->has('error')): ?>
					<?php $__env->startSection('admin::custom_js'); ?>
					<script>
						Swal.fire({
						  position: 'center',
						  type: 'error',
						  title: " <?php echo e(session()->get('error')); ?> ",
						  showConfirmButton: false,
						  timer: 3000
						})
					</script>
					<?php $__env->stopSection(); ?>
				<?php endif; ?>

			</div>
		</div>
	</div>

	<div class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-sm-12 text-right">
					<a href="<?php echo e(route('farms')); ?>" class="btn btn-primary">
						 Back
					</a>
				</div>
				<div class="col-md-12">

				    <div class="card ">
				        <div class="card-header card-header-rose card-header-text">
				            <div class="card-text">
				                <h4 class="card-title">Edit Farm</h4>
				            </div>
				        </div>
				        <div class="card-body">
				            	<?php echo e(Form::open(array('url' => url('admin/farm-edit'), 'method'=>'post', 'class'=>'form-horizontal', 'id'=>'addFarm', 'enctype'=>'multipart/form-data'))); ?>

											<?php echo csrf_field(); ?>


											<div class="row">
				                	<div class="col-sm-2 col-form-label">
				                     	<label for="farm_name" class="bmd-label-floating"> Select User *</label>
				                    </div>
				                    <div class="col-sm-10">
				                        <div class="form-group bmd-form-group">
																	<select class="selectpicker" data-style="select-with-transition" data-size="7" autocomplete="off" name="user_id" id="user_id" required>
					                            <option value="">Choose User</option>
					                            <?php $__currentLoopData = $userArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																				<?php if($key==$farms->user_id): ?>
					                            	<option value="<?php echo e($key); ?>" selected> <?php echo e($cat); ?> </option>
																				<?php else: ?>
																				<option value="<?php echo e($key); ?>"> <?php echo e($cat); ?> </option>
																				<?php endif; ?>
					                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				                         	</select>
				                          	<?php if($errors->has('user_id')): ?>
																		<span class="error" role="user_id">
																			<strong><?php echo e($errors->first('user_id')); ?></strong>
																		</span>
																		<?php endif; ?>
				                        </div>
				                    </div>
				                </div>

				                <div class="row">
				                	<div class="col-sm-2 col-form-label">
				                     	<label for="farm_name" class="bmd-label-floating"> Farm Name *</label>
				                     </div>
				                    <div class="col-sm-10">
				                        <div class="form-group bmd-form-group">
				                            <input type="text" name="farm_name" id="farm_name" class="form-control" autocomplete="off"  value="<?php echo e($farms->farm_name); ?>" required>
				                            <?php if($errors->has('farm_name')): ?>
																			<span class="error" role="farm_name">
																				<strong><?php echo e($errors->first('farm_name')); ?></strong>
																			</span>
																		<?php endif; ?>
				                        </div>
				                    </div>
				                </div>

												<div class="row">
				                	<div class="col-sm-2 col-form-label">
				                     	<label for="land_size" class="bmd-label-floating"> Land Size *</label>
				                     </div>
				                    <div class="col-sm-10">
				                        <div class="form-group bmd-form-group">
				                            <input type="text" name="land_size" id="land_size" class="form-control" autocomplete="off"  value="<?php echo e($farms->land_size); ?>" required>
				                            <?php if($errors->has('land_size')): ?>
																			<span class="error" role="land_size">
																				<strong><?php echo e($errors->first('land_size')); ?></strong>
																			</span>
																		<?php endif; ?>
				                        </div>
				                    </div>
				                </div>


												<div class="row">
				                	<div class="col-sm-2 col-form-label">
				                     	<label for="main_commodities" class="bmd-label-floating"> Main Commodities *</label>
				                     </div>
				                    <div class="col-sm-10">
				                        <div class="form-group bmd-form-group">
				                            <input type="text" name="main_commodities" id="main_commodities" class="form-control" autocomplete="off"  value="<?php echo e($farms->main_commodities); ?>" required>
				                            <?php if($errors->has('main_commodities')): ?>
																			<span class="error" role="main_commodities">
																				<strong><?php echo e($errors->first('main_commodities')); ?></strong>
																			</span>
																		<?php endif; ?>
				                        </div>
				                    </div>
				                </div>

												<div class="row">
				                	<div class="col-sm-2 col-form-label">
				                     	<label for="address_line_1" class="bmd-label-floating"> Address Line 1 *</label>
				                     </div>
				                    <div class="col-sm-10">
				                        <div class="form-group bmd-form-group">
				                            <input type="text" name="address_line_1" id="address_line_1" class="form-control" autocomplete="off"  value="<?php echo e($farms->address_line_1); ?>" required>
				                            <?php if($errors->has('address_line_1')): ?>
																			<span class="error" role="address_line_1">
																				<strong><?php echo e($errors->first('address_line_1')); ?></strong>
																			</span>
																		<?php endif; ?>
				                        </div>
				                    </div>
				                </div>

												<div class="row">
				                	<div class="col-sm-2 col-form-label">
				                     	<label for="address_line_2" class="bmd-label-floating"> Address Line 2 *</label>
				                     </div>
				                    <div class="col-sm-10">
				                        <div class="form-group bmd-form-group">
				                            <input type="text" name="address_line_2" id="address_line_2" class="form-control" autocomplete="off"  value="<?php echo e($farms->address_line_2); ?>" required>
				                            <?php if($errors->has('address_line_2')): ?>
																			<span class="error" role="address_line_2">
																				<strong><?php echo e($errors->first('address_line_2')); ?></strong>
																			</span>
																		<?php endif; ?>
				                        </div>
				                    </div>
				                </div>

												<div class="row">
				                	<div class="col-sm-2 col-form-label">
				                     	<label for="city" class="bmd-label-floating"> City *</label>
				                     </div>
				                    <div class="col-sm-10">
				                        <div class="form-group bmd-form-group">
				                            <input type="text" name="city" id="city" class="form-control" autocomplete="off"  value="<?php echo e($farms->city); ?>" required>
				                            <?php if($errors->has('city')): ?>
																			<span class="error" role="city">
																				<strong><?php echo e($errors->first('city')); ?></strong>
																			</span>
																		<?php endif; ?>
				                        </div>
				                    </div>
				                </div>

												<div class="row">
				                	<div class="col-sm-2 col-form-label">
				                     	<label for="district" class="bmd-label-floating"> District *</label>
				                     </div>
				                    <div class="col-sm-10">
				                        <div class="form-group bmd-form-group">
				                            <input type="text" name="district" id="district" class="form-control" autocomplete="off"  value="<?php echo e($farms->district); ?>" required>
				                            <?php if($errors->has('district')): ?>
																			<span class="error" role="district">
																				<strong><?php echo e($errors->first('district')); ?></strong>
																			</span>
																		<?php endif; ?>
				                        </div>
				                    </div>
				                </div>											

												<div class="row">
				                	<div class="col-sm-2 col-form-label">
				                     	<label for="postal_code" class="bmd-label-floating"> Postal Code *</label>
				                     </div>
				                    <div class="col-sm-10">
				                        <div class="form-group bmd-form-group">
				                            <input type="text" name="postal_code" id="postal_code" class="form-control" autocomplete="off"  value="<?php echo e($farms->postal_code); ?>" required>
				                            <?php if($errors->has('postal_code')): ?>
																			<span class="error" role="postal_code">
																				<strong><?php echo e($errors->first('postal_code')); ?></strong>
																			</span>
																		<?php endif; ?>
				                        </div>
				                    </div>
				                </div>

				                <!-- <div class="row">
				                    <label class="col-sm-2 col-form-label">Status</label>
				                    <div class="col-sm-10">
				                        <div class="form-check statchk">
				                          <label class="form-check-label">
				                            <input class="form-check-input" type="checkbox" name="status" id="status" checked=""> 
				                            <span class="form-check-sign">
				                              <span class="check"></span>
				                            </span>
				                          </label>
				                        </div>
				                    </div>
				                </div> -->

				                <div class="row">
				                    <div class="col-sm-2 col-form-label">
															<div class="card-footer ">
																<input type="hidden" name="id" value="<?php echo e($farms->id); ?>">
						                  	<button type="submit" class="btn btn-fill btn-rose">Submit<div class="ripple-container"></div></button>
						                	</div>
				                    </div>
				                </div>

										<?php echo e(Form::close()); ?>

				            <!-- </form> -->
				        </div>
				    </div>
					<!-- /card -->

				</div>
			</div>
			<!-- /row -->
		</div>
		<!-- /container-fluid -->
	</div>
	<!-- /content -->
</div>
<!-- content -->

<?php $__env->stopSection(); ?>


<?php $__env->startSection('admin::custom_js'); ?>

<script type="text/javascript">
$(document).ready(function () {
	$('#addFarm').validate();
});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin::layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>