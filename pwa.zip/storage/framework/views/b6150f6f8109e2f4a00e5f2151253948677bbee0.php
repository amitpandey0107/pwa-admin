<?php $__env->startSection('admin::title', 'Leads'); ?>

<?php $__env->startSection('admin::pagetitle', 'Track Leads'); ?>

<?php $__env->startSection('admin::content'); ?>

<style>
.statchk .form-check-label {margin-top: 14px;}
.imgmt{margin-top: 20px;}
.form-group input[type=file] {opacity: 1; position: relative; z-index: 0; }
select#product_subcateory {border: none; border-bottom: 1px solid #ccc; width: 27%; color: #999; position:relative;}
</style>


<style>
      /* Always set the map height explicitly to define the size of the div
       * element that contains the map. */
      #map {
        height: 500px;
				width: 100%;
      }
      /* Optional: Makes the sample page fill the window. */
      html, body {
        height: 100%;
        margin: 0;
        padding: 0;
      }
      #floating-panel {
        position: absolute;
        top: 10px;
        left: 25%;
        z-index: 5;
        background-color: #fff;
        padding: 5px;
        border: 1px solid #999;
        text-align: center;
        font-family: 'Roboto','sans-serif';
        line-height: 30px;
        padding-left: 10px;
      }
      #warnings-panel {
        width: 100%;
        height:10%;
        text-align: center;
      }
    </style>

<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-12">
				<?php if(count($errors) > 0): ?>
			       <div class = "alert alert-danger">
			          <ul>
			             <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			                <li><?php echo e($error); ?></li>
			             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			          </ul>
			       </div>
			    <?php endif; ?>

			    <?php if(!empty($successMsg)): ?>
			      <div class="alert alert-success"> <?php echo e($successMsg); ?></div>
			    <?php endif; ?>
			</div>
		</div>

		<div class="row">
			<div class="col-sm-12">
				<?php if(session()->has('success')): ?>
					<?php $__env->startSection('admin::custom_js'); ?>
					<script>
						Swal.fire({
						  position: 'center',
						  type: 'success',
						  title: " <?php echo e(session()->get('success')); ?> ",
						  showConfirmButton: false,
						  timer: 3000
						})
					</script>
					<?php $__env->stopSection(); ?>
				<?php endif; ?>

				<?php if(session()->has('error')): ?>
					<?php $__env->startSection('admin::custom_js'); ?>
					<script>
						Swal.fire({
						  position: 'center',
						  type: 'error',
						  title: " <?php echo e(session()->get('error')); ?> ",
						  showConfirmButton: false,
						  timer: 3000
						})
					</script>
					<?php $__env->stopSection(); ?>
				<?php endif; ?>

			</div>
		</div>
	</div>

	<style>
	.bmd-form-group {position:relative; top:6px;}
	</style>



	<div class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">

				    <div class="card ">
								<div class="card-header card-header-success card-header-icon">
											<div class="card-icon">
													<i class="material-icons">assignment</i>
											</div>
											<h4 class="card-title">Lead Track
													<a href="<?php echo e(route('leads')); ?>">
															<button class="btn btn-success" style="float:right">Back</button>
													</a>
											</h4>
									</div>
				        <div class="card-body">
									<p>Lead Latitude : <?php echo e($data_array['latitude']); ?></p>
									<p>Lead Longitude : <?php echo e($data_array['longitude']); ?></p>				            
									<div id="floating-panel">
									<b>Start: </b>
									<select id="start">
										<option value="penn station, new york, ny">Penn Station</option>
										<option value="Delhi, India">Delhi, India</option>
										<option value="grand central station, new york, ny">Grand Central Station</option>
										<option value="625 8th Avenue, New York, NY, 10018">Port Authority Bus Terminal</option>
										<option value="staten island ferry terminal, new york, ny">Staten Island Ferry Terminal</option>
										<option value="101 E 125th Street, New York, NY">Harlem - 125th St Station</option>
									</select>
									<b>End: </b>
									<select id="end">
										<option value="260 Broadway New York NY 10007">City Hall</option>
										<option value="Jaipur, India">Jaipur, India</option>
										<option value="W 49th St & 5th Ave, New York, NY 10020">Rockefeller Center</option>
										<option value="moma, New York, NY">MOMA</option>
										<option value="350 5th Ave, New York, NY, 10118">Empire State Building</option>
										<option value="253 West 125th Street, New York, NY">Apollo Theater</option>
										<option value="1 Wall St, New York, NY">Wall St</option>
									</select>
									</div>
									<div id="map"></div>
									&nbsp;
									<div id="warnings-panel"></div>
				        </div>
				    </div>
					<!-- /card -->

				</div>
			</div>
			<!-- /row -->
		</div>
		<!-- /container-fluid -->
	</div>
	<!-- /content -->
</div>
<!-- content -->

<?php $__env->stopSection(); ?>


<?php $__env->startSection('admin::custom_js'); ?>

<script type="text/javascript">
$(document).ready(function () {
	$('#addFarm').validate();
});
</script>


<script>
      function initMap() {
        var markerArray = [];

        // Instantiate a directions service.
        var directionsService = new google.maps.DirectionsService;

        // Create a map and center it on Manhattan.
        var map = new google.maps.Map(document.getElementById('map'), {
          zoom: 13,
          center: {lat: 40.771, lng: -73.974}
        });

        // Create a renderer for directions and bind it to the map.
        var directionsRenderer = new google.maps.DirectionsRenderer({map: map});

        // Instantiate an info window to hold step text.
        var stepDisplay = new google.maps.InfoWindow;

        // Display the route between the initial start and end selections.
        calculateAndDisplayRoute(
            directionsRenderer, directionsService, markerArray, stepDisplay, map);
        // Listen to change events from the start and end lists.
        var onChangeHandler = function() {
          calculateAndDisplayRoute(
              directionsRenderer, directionsService, markerArray, stepDisplay, map);
        };
        document.getElementById('start').addEventListener('change', onChangeHandler);
        document.getElementById('end').addEventListener('change', onChangeHandler);
      }

      function calculateAndDisplayRoute(directionsRenderer, directionsService,
          markerArray, stepDisplay, map) {
        // First, remove any existing markers from the map.
        for (var i = 0; i < markerArray.length; i++) {
          markerArray[i].setMap(null);
        }

        // Retrieve the start and end locations and create a DirectionsRequest using
        // WALKING directions.
        directionsService.route({
          origin: document.getElementById('start').value,
          destination: document.getElementById('end').value,
          travelMode: 'DRIVING'
        }, function(response, status) {
          // Route the directions and pass the response to a function to create
          // markers for each step.
          if (status === 'OK') {
            document.getElementById('warnings-panel').innerHTML =
                '<b>' + response.routes[0].warnings + '</b>';
            directionsRenderer.setDirections(response);
            showSteps(response, markerArray, stepDisplay, map);
          } else {
            window.alert('Directions request failed due to ' + status);
          }
        });
      }

      function showSteps(directionResult, markerArray, stepDisplay, map) {
        // For each step, place a marker, and add the text to the marker's infowindow.
        // Also attach the marker to an array so we can keep track of it and remove it
        // when calculating new routes.
        var myRoute = directionResult.routes[0].legs[0];
        for (var i = 0; i < myRoute.steps.length; i++) {
          var marker = markerArray[i] = markerArray[i] || new google.maps.Marker;
          marker.setMap(map);
          marker.setPosition(myRoute.steps[i].start_location);
          attachInstructionText(
              stepDisplay, marker, myRoute.steps[i].instructions, map);
        }
      }

      function attachInstructionText(stepDisplay, marker, text, map) {
        google.maps.event.addListener(marker, 'click', function() {
          // Open an info window when the marker is clicked on, containing the text
          // of the step.
          stepDisplay.setContent(text);
          stepDisplay.open(map, marker);
        });
      }
    </script>

<!-- <script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?key=AIzaSyBhra7AFQucYqE0dwZpwXzy5Yo3hPMMVJ8&sensor=false&libraries=places"></script> -->
<script async defer
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDBflOLy17eAONIF2xfL-WAWfF1Rv1hiT4&callback=initMap">
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin::layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>